/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

/**
 *
 * @author Cayetano
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Urna bolas = new Urna (6,6);
        String ColorBola = "";
        String ColorBola2 = "";
        while (bolas.totalBolas() != 0){
            if (bolas.totalBolas() != 1){
                ColorBola = bolas.bola();
                ColorBola2 = bolas.bola();
                if (ColorBola == ColorBola2){
                    bolas.ponerBlanca();
                }
                else{
                    bolas.ponerNegra();
                }
            }
            else{
                ColorBola = bolas.bola();
            }
        }
        if (ColorBola != ""){
            System.out.println("La ultima bola sacada es de color " + ColorBola + ".");
        }
    }
}
