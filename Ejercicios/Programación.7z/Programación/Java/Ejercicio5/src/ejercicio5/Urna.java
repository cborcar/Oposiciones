/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

/**
 *
 * @author Cayetano
 */
public class Urna {
    //ATRIBUTOS.
    private int blancas;
    private int negras;
    //MÉTODOS
    //Constructor.
    public Urna(int bl, int ne){
        if ((bl < 0) || (ne < 0)){
            System.out.println("Error: Has especificado un numero negativo de bolas.");
        }
        else{
            if ((bl == 0) && (ne == 0)){
                System.out.println("Error: No has introducido bolas en la urna.");
            }
            else{
                blancas = bl;
                negras = ne; 
            }
        }
    }
    //Método que extrae una bola aleatoriamente y devuelve su color.
    public String bola(){
        //Primero sumamos el numero de bolas.
        int TotalBolas = totalBolas();
        double BolaAExtraer = 0;
        BolaAExtraer = Math.floor(Math.random() * TotalBolas); //El Math.floor es para que de un número entero.
        BolaAExtraer += 1;
        String ColorBola;
        if (BolaAExtraer <= blancas){
            ColorBola = "blanca";
            blancas -= 1;
        }
        else{
            ColorBola = "negra";
            negras -= 1;
        }
        return (ColorBola);
    }
    //Método que introduce una bola blanca.
    public void ponerBlanca(){
        blancas += 1;
    }
    //Método que introduce una bola negra.
    public void ponerNegra(){
        negras += 1;
    }
    //Método que devuelve el número total de bolas que hay en la urna.
    public int totalBolas(){
        return (blancas + negras);
    }
    //Método que devuelve una cadena con los valores de las bolas.
    public String toString(){
        return ("En la urna hay " + blancas + " bolas blancas y " + negras + " bolas negras.");
    }
  
}
