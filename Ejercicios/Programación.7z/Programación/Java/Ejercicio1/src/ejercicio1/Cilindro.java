/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

/**
 *
 * @author Cayetano
 */
public class Cilindro {
    //ATRIBUTOS.
    private double altura;
    private Circulo base;
    //MÉTODOS.
    //Constructores.
    public Cilindro(){}
    public Cilindro(Circulo b, double a){
        base = b;
        altura = a;
    }
    //Métodos de devolución.
    public Circulo base(){
        return base;
    }
    public double altura(){
        return altura;
    }
    //Métodos de asignación.
    public void base(Circulo b){
        base = b;
    }
    public void altura(double a){
        altura = a;
    }
    //Método que traslada la base a otra posición.
    public void trasladar(double a, double b){
        base.trasladar(a,b);
    }
    //Método que imprime por pantalla la base y la altura del cilindro.
    public String toString(){
        String cadena;
        cadena = base.toString() + "; Altura = " + altura();
        return cadena;
    }  
}
