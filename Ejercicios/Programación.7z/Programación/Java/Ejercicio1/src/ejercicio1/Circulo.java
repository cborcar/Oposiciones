/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;
/**
 *
 * @author Cayetano
 */
public class Circulo {
    //ATRIBUTOS.
    private double radio;
    private Punto centro;
    //MÉTODOS.
    //Constructores.
    public Circulo(){}
    public Circulo(Punto p, double r){
        centro = p;
        radio = r;
    }
    //Métodos de devolución.
    public Punto centro(){
        return centro;
    }
    public double radio(){
        return radio;
    }
    //Métodos de asignación.
    public void centro(Punto p){
        centro = p;
    }
    public void radio (double r){
        radio = r;
    }
    //Método que traslada el centro a otra posición.
    public void trasladar(double a, double b){
        centro.trasladar(a,b);
    }
    //Método que imprime por pantalla las coordenadas del centro y el radio del cículo..
    public String toString(){
        String cadena;
        //cadena = "Centro = [" + centro.x() + "," + centro.y() + "]; Radio = " + radio();
        //La forma anterior es correcta, pero es mejor hacerlo así.
        cadena = "Centro = " + centro.toString() + "; Radio = " + radio();
        return cadena;
    }   
}
