/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

/**
 *
 * @author Cayetano
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Punto centroBase = new Punto(3.0, 5.0);
        Circulo base = new Circulo(centroBase, 4.0);
        Cilindro miCilindro = new Cilindro(base, 10.0);
        
        System.out.println(miCilindro); //Se ejecuta el método toString, es como poner: System.out.println(miCilindro.toString());
        
        miCilindro.trasladar(2.0, 2.0);
        System.out.println(miCilindro);
        
        System.out.println(new Cilindro(new Circulo(new Punto(3.0, 5.0), 4.0), 10.0));
    }
}
