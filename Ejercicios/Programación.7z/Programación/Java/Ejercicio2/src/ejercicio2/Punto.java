/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

/**
 *
 * @author Cayetano
 */
public class Punto {
    //ATRIBUTOS. 
    private double x;
    private double y;
    //MÉTODOS.
    //Constructores.
    public Punto(){}
    public Punto(double a, double b){
        x = a;
        y = b;
    }
    //Métodos de devolución.
    public double x(){
        return x;
    }
    public double y(){
        return y;
    }
    //Método que calcula la distancia entre 2 puntos. Para ello se llama al método indicando un punto.
    public double distancia (Punto p){
        double valor1 = x() - p.x(); //(x1 - x2)
        valor1 *= valor1; //(x1 - x2)^2
        double valor2 = y() - p.y();
        valor2 *= valor2;
        return (Math.sqrt(valor1 + valor2));  //Finalmente hacemos la raiz cuadrada y la devolvemos.
    }
    //Métodos de asignación.
    public void x(double a){
        x = a;
    }
    public void y(double b){
        y = b;
    }
    //Método que desplaza el punto a otra posición.
    public void trasladar(double a, double b){
        x += a;
        y += b;
    }
    //Método que imprime por pantalla las coordenadas del punto.
    public String toString(){
        String cadena;
        cadena = "P(" + x() + "," + y() + ")";
        return cadena;
    }   
}         