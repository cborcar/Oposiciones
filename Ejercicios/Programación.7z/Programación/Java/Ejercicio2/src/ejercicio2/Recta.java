/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

/**
 *
 * @author Cayetano
 */
public class Recta {
    //ATRIBUTOS: Una recta está compuesto por un punto por el que pasa y por un vector director.
    private Punto pto;
    private Vector direccion;  
    //MÉTODOS.
    //Constructores.
    public Recta (Vector v, Punto p){
        pto = p;
        direccion = v;
    }        
    public Recta (Punto p1, Punto p2){
        pto = p2; //Da igual que pongamos p2 o p1, se supone que es cualquier punto por el que pase.
        direccion = new Vector (p1,p2);
    }
    //Método que determina si una recta pasa por un punto o no.
    public boolean pasaPor(Punto p){
        //Una recta pasa por un punto p si el vector formado por p y un punto de la recta es paralelo al vector director de la recta.
        //Primero hay que crear el vector formado por p y un punto de la recta.
        Vector vector1;
        if (p.x() > pto.x()){
            vector1 = new Vector (p, pto);
        }
        else{
            vector1 = new Vector (pto, p);
        }
        //Ahora comprobamos si son paralelos.
        if (direccion.paraleloA(vector1)){
            return true;
        }
        else{
            return false;
        }
    }
    //Método que comprueba si dos rectas son paralelas.
    public boolean paralelaA(Recta r){
        //Que sea paralelo quiere decir que: vx*uy == vy*ux
        if (direccion.paraleloA(r.direccion)){
            return true;
        }
        else{
            return false;
        }
    }
    //Método que devuelve una recta paralela a otra que empiece en un punto dado.
    public Recta paralelaPor(Punto p){
        //Una recta paralela a otra, es una recta que tiene la misma dirección (vector). Por tanto, la direccion es la misma y el punto el que nos dan.
        return (new Recta (direccion,p));    
    }
    //Método que devuelve la recta perpendicular a otra recta dado un punto.
    public Recta perpendicularPor(Punto p){
        //Una recta perpendicular es una recta cuyo vector es ortogonal a la recta.
        return (new Recta (direccion.ortogonal(), p));
    }
    //Método que determina el punto donde cortan dos rectas.
    public Punto interseccionCon(Recta r){
        //Dos rectas R(V(vx, vy),P(px,py) y R(V(ux,uy),P(qx,qy) se cortan en el punto P(x,y) si:
        // x = (d1 * ux - vx * d2) / d
        // y = - (vy * d2 - uy * d1) / d
        //Siendo
        // d = uy * vx - vy * ux
        // d1 = vx * py - vy * px
        // d2 = ux * qy - uy * qx
        //Calculamos d, d1 y d2
        double d = (r.direccion.componenteY() * direccion.componenteX()) - (direccion.componenteY() * r.direccion.componenteX());
        double d1 = (direccion.componenteX() * pto.y()) - (direccion.componenteY() * pto.x());
        double d2 = (r.direccion.componenteX() * r.pto.y()) - (r.direccion.componenteY() * r.pto.x());
        //Calculo las coordenadas x e y.
        double x = ((d1 * r.direccion.componenteX()) - (direccion.componenteX() * d2)) / d;
        double y = - ((direccion.componenteY() * d2) - (r.direccion.componenteY() * d1)) / d;
        return (new Punto(x,y));
    }
    //Método que devuelva la distancia entre una recta y un punto.
    public double distanciaDesde(Punto p){
        //Para calcular la distancia entre un punto y una recta, primero debemos calcular la recta perpendicular a la recta dada que pase por ese punto.;
        Recta RectaAOperar = new Recta (direccion, pto);
        Recta RectaPerpendicular = RectaAOperar.perpendicularPor(p);
        //Ahora hay que calcular el punto donde cortan las 2 rectas.
        Punto corte = (RectaAOperar.interseccionCon(RectaPerpendicular));
        //Ya tenemos el punto de corte perpendicular con el punto dado, calculamos la distancia entre esos dos puntos.
        return (corte.distancia(p));
    }
    //Método que imprime por pantalla la recta.
    public String toString(){
        String cadena;
        cadena = "R[" + direccion.toString() + "," + pto.toString() + "]";
        return cadena; 
    }   
}