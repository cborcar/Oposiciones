/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

/**
 *
 * @author Cayetano
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Punto amarilla = new Punto (-3,3);
        Punto azul = new Punto (3,3);
        Punto rosa = new Punto (0,0);
        Tesoro tesoro = new Tesoro (amarilla,azul,rosa);
        tesoro.calculaPosiciones();
        System.out.println("Clavamos la estaca amarilla en la posicion: " + tesoro.estacaAmarilla());
        System.out.println("Clavamos la estaca azul en la posicion: " + tesoro.estacaAzul());
        System.out.println("El tesoro se encuentra en las coordenadas: " + tesoro.Tesoro());  
    }
}
