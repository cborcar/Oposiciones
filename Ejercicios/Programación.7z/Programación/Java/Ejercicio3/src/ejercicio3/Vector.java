 /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

/**
 *
 * @author Cayetano
 */
public class Vector {
    //ATRIBUTOS: Un vector director es un vector que tiene como origen (0,0), solo vale para determinar la dirección.
    private Punto extremo;
    //MÉTODOS.
    //Constructores.
    public Vector(double x, double y){
        extremo = new Punto (x,y);
    }
    public Vector(Punto e){
        extremo = e;
    }
    public Vector(Punto origen, Punto extremo){
        this.extremo = new Punto((extremo.x() - origen.x()), (extremo.y() - origen.y()));  
    }
    //Métodos de devolución.
    public double componenteX(){
        return (extremo.x());
    }
    public double componenteY(){
        return (extremo.y());
    }
    //Método que devuelve el módulo de un vector.
    public double modulo(){
        //El módulo se calcula: raiz cuadrada de [x^2 + y^2]
        double valor1 = componenteX() * componenteX();
        double valor2 = componenteY() * componenteY();
        return (Math.sqrt(valor1 + valor2));
    }
    //Método que calcula y devuelve el ortogonal de un vector.
    public Vector ortogonal(){
        double x = componenteX();
        double y = -componenteY();
        Punto punto1 = new Punto(y,x);
        Vector vector1 = new Vector(punto1);
        return (vector1);    
    }
    //Método que comprueba si 2 vectores son paralelos.
    public boolean paraleloA(Vector v){
        //Que sea paralelo quiere decir que: vx*uy == vy*ux
        double valor1 = componenteX() * v.componenteY();
        double valor2 = componenteY() * v.componenteX();
        if (valor1 == valor2){
            return true;
        }
        else{
            return false;
        }
    }
    //Método que devuelve el punto donde quedaría el extremo del vector si el origen se coloca org.
    public Punto extremoDesde(Punto org){
        extremo.trasladar(org.x(), org.y());
        return extremo;
    }
    //Método que imprime por pantalla el vector.
    public String toString(){
        String cadena;
        cadena = "V(" + componenteX() + "," + componenteY() + ")";
        return cadena; 
    }   
}