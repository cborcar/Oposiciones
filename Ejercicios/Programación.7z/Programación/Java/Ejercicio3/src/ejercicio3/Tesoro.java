/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

/**
 *
 * @author Cayetano
 */
public class Tesoro {
    //ATRIBUTOS.
    private Punto PalmeraRosa;
    private Punto PalmeraAmarilla;
    private Punto PalmeraAzul;
    private Punto EstacaAmarilla;
    private Punto EstacaAzul;
    private Punto PosicionTesoro;
    //MÉTODOS
    //Constructor.
    public Tesoro (Punto a, Punto b, Punto c){
        PalmeraAmarilla = a;
        PalmeraAzul = b;
        PalmeraRosa = c;
        EstacaAmarilla = new Punto (0,0);
        EstacaAzul = new Punto (0,0);
        PosicionTesoro = new Punto(0,0);
    }
    //Métodos que cambian la palmeras de posición y recalculan las posiciones de las estacas y el tesoro.
    public void cambiaPalmeraAmarilla(Punto p){
        PalmeraAmarilla = p;
        calculaPosiciones();
    }
    public void cambiaPalmeraAzul(Punto p){
        PalmeraAzul = p;
        calculaPosiciones();
    }
    public void cambiaPalmeraRosa(Punto p){
        PalmeraRosa = p;
        calculaPosiciones();
    }
    //Métodos de devolución.
    public Punto estacaAmarilla(){
        return EstacaAmarilla;
    }
    public Punto estacaAzul(){
        return EstacaAzul;
    }
    public Punto Tesoro(){
        return PosicionTesoro;
    }
    //Método que calcula la posición de las estacas y la del tesoro.
    public void calculaPosiciones(){
        //PRIMERO: CALCULAR LA POSICIÓN DE LA ESTACA AMARILLA.
        //Para ello crearemos un vector cuyo punto origen es la palmera rosa y extremo es la palmera amarilla.
        Vector VectorRosaAmarilla = new Vector (PalmeraRosa, PalmeraAmarilla);
        //El ejercicio dice que hay que contar los pasos (distancia) pero no hace falta, ya que la longitud del vector determinará la distancia.
        //Si giramos el vector 90 grados y lo colocamos en la palmera amarilla, el extremo será la posición de la estaca.
        VectorRosaAmarilla = VectorRosaAmarilla.ortogonal();
        EstacaAmarilla = VectorRosaAmarilla.extremoDesde(PalmeraAmarilla);
        
        //SEGUNDO: CALCULAR LA POSICIÓN DE LA ESTACA AZUL.
        //Igual que antes, se crea un vector cuyo punto origen es la palmera rosa y extremo es la palmera azul.
        Vector VectorRosaAzul = new Vector (PalmeraRosa, PalmeraAzul);
        //Girar el vector 90 grados en sentido de las agujas del reloj es lo mismo que girarlo 3 veces en sentido contrario.
        VectorRosaAzul = VectorRosaAzul.ortogonal();
        VectorRosaAzul = VectorRosaAzul.ortogonal();
        VectorRosaAzul = VectorRosaAzul.ortogonal();
        //Finalmente trasladamos el origen del vector a la palmera azul y el extremo será la posición de la estaca.
        EstacaAzul = VectorRosaAzul.extremoDesde(PalmeraAzul);
        
        //TERCERO: CALCULAR LA POSICIÓN DEL TESORO.
        //Para ello crearemos un vector desde la estaca amarilla a la azul, reduciremos su tamaño a la mitad y lo colocamos en la estaca amarilla, el extremo será la posición del tesoro.
        Vector EstacasAmarilloAzul = new Vector (EstacaAmarilla,EstacaAzul);
        Vector EstacasAmarilloAzulMitad = new Vector(EstacasAmarilloAzul.componenteX() / 2, EstacasAmarilloAzul.componenteY() / 2);
        PosicionTesoro = EstacasAmarilloAzulMitad.extremoDesde(EstacaAmarilla);
    }  
}