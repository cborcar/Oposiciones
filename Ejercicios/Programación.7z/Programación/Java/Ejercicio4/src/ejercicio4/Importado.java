/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author Cayetano
 */
public class Importado extends Coche{ //Importado es una clase hija de coche.
    //ATRIBUTOS.
    private double Homologacion;
    //MÉTODOS.
    //Constructor.
    public Importado (String n, double p, double h){
        super(n,p); //Los atributos que contenga el padre se construyen con el constructor del padre.
        Homologacion = h; //Los atributos que no tenga el padre hay que ponerlos.
    }
    //Método que calcula el precio total.
    public double precioTotal(){
        return (super.precioTotal() + Homologacion); //super.precioTotal() llama al método precioTotal del padre.
    }
}
