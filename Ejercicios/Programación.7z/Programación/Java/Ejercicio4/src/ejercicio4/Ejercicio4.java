/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author Cayetano
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Coche[] cs = { new Coche("Panda", 15000), new Importado ("Mercedes", 35000, 5000), new Coche ("Toledo", 21000), new Importado ("Jaguar", 41000, 6000), new Importado ("Porche", 44000, 7000) };
        for (Coche c : cs){
            System.out.println(c);
        }
        //Cambiamos el iva a todos los coches
        for (int i = 0; i<cs.length ; i++){
            cs[i].setPiva(0.18);
        }
        System.out.println("Con IVA de 18%");
        for (Coche c : cs){
            System.out.println(c);
        } 
    }
}
