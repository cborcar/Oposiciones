/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;
 
/**
 *
 * @author Cayetano
 */
public class Coche {
    //ATRIBUTOS.
    protected double PIVA;
    protected String Nombre;
    protected double Precio;
    //MÉTODOS.
    //Constructor.
    public Coche (String n, double p){
        Nombre = n;
        Precio = p;
        PIVA = 0.16;
    }
    //Método de asignación del IVA.
    public void setPiva(double d){
        PIVA = d;
    }
    //Método que calcule el precio total.
    public double precioTotal(){
        return (Precio + (Precio * PIVA));
    }
    //Método que forma una cadena con el nombre y su precio.
    public String toString(){
        return (Nombre + " -> " + precioTotal());
    }
}
