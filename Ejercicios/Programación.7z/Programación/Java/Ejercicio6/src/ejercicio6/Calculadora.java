/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio6;

/**
 *
 * @author Cayetano
 */ 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Calculadora extends JFrame implements ActionListener{
    //ATRIBUTOS.
    JButton boton1, boton2, boton3, boton4, boton5, boton6, boton7, boton8, boton9, boton0;
    JButton botonCE, botonMas, botonMenos, botonPor, botonEntre, botonIgual, botonMasMenos;
    JTextField Resultado;
    String Texto = "", operador = "";
    JLabel Creditos, EtiquetaVacia;
    double operando1, operando2, MasMenos;
    //MÉTODOS.
    //Método que crea la interfaz gráfica.
    public void iniciar(){
        //Lo primero de todo es inicializar los elementos gráficos (Botones, etiquetas, etc.)
        Creditos = new JLabel("Realizado por: Cayetano Borja Carrillo");
        EtiquetaVacia = new JLabel(" ");
        Resultado = new JTextField(" ");
        Resultado.setEditable(false); //Lo ponemos que no se pueda editar para no pode escribir a mano, sino que muestre solo las acciones de los botones.
        boton1 = new JButton("1"); //El texto será "1".
        boton2 = new JButton("2");
        boton3 = new JButton("3");
        boton4 = new JButton("4");
        boton5 = new JButton("5");
        boton6 = new JButton("6");
        boton7 = new JButton("7");
        boton8 = new JButton("8");
        boton9 = new JButton("9");
        boton0 = new JButton("0");
        botonCE = new JButton("CE");
        botonMas = new JButton("+");
        botonMenos = new JButton("-");
        botonIgual = new JButton("=");
        botonPor = new JButton("*");
        botonEntre = new JButton("/");
        botonMasMenos = new JButton("+/-");
        
        //Ahora realizaremos el diseño. Una ventana está compuesto por JFrame, Menu Bar y Content Pane.
        //JFrame consiste en la parte superior de la ventana (Titulo, icono, etc)
        //Content Pane es el centro de la ventana (donde irán los elementos).
        JFrame ventana = new JFrame("Calculadora"); //Creamos el objeto ventana de tipo JFrame con título Calculadora.
        ventana.setIconImage (new ImageIcon("./Icono.png").getImage());
        Container cpane = ventana.getContentPane();  //Creamos el objeto cpane de tipo Contenedor, este será el Content Pane de la ventana.
        //Si empezamos a introducir elementos dentro del Contenedor Content Pane, los elementos irán seguidos de arriba hacia abajo e izquierda hacia derecha.
        //Nosotros no queremos eso, queremos hacer un diseño. Para ello, el contenedor se puede dividir en subsecciones, cada sección tendrá un contenedor y en él se podrán introducir elementos o volver a dividirlo.
        //Existen varias formas de dividir un contenedor. FLOWLAYOUT: Contenedor normal Arriba-abajo, izquierda-derecha. BORDERLAYOUT: divide el contenedor en 5 partes
        //NORTE, SUR, ESTE, OESTE Y CENTRO. GRIDLAYOUT: Divide el contenedor en una rejilla de X filas e Y columnas.
        //Para el diseño de la calculadora, voy a dividir el contenedor principal en 5 utilizando BORDERLAYOUT.
        //NOTA: Al maximizar la ventana en BorderLayout, los botones se agrandarán adaptándose a la pantalla. Las zonas norte y sur estirarán en horizonal. Este y oeste en vertical y Central en ambos.
        //NOTA: Al maximizar la ventana en GridLayout, los botones no se maximizarán, es decir, tendrán siempre el mismo tamaño.
        cpane.setLayout(new BorderLayout());
        //En la parte NORTE meteré un cuadro de texto donde irá el resultado.
        cpane.add(Resultado, BorderLayout.NORTH);
        //En la parte SUR irá una etiqueta con mi nombre.
        cpane.add(Creditos, BorderLayout.SOUTH);
        //En la parte OESTE irá el botón CE.
        cpane.add(botonCE, BorderLayout.WEST);
        //En la parte CENTRO introduciré un nuevo contenedor de tipo rejilla para que vayan los botones del 0 al 9.
        JPanel seccionCentral = new JPanel(); //Creamos un nuevo contenedor llamado seccionCentral, este contenedor irá en la parte CENTRO.
        seccionCentral.setLayout(new GridLayout(4,3)); //Será de tipo rejilla de 4 filas por 3 columnas.
        seccionCentral.add(boton1); //Añadirmos los botones.
        seccionCentral.add(boton2);
        seccionCentral.add(boton3);
        seccionCentral.add(boton4);
        seccionCentral.add(boton5);
        seccionCentral.add(boton6);
        seccionCentral.add(boton7);
        seccionCentral.add(boton8);
        seccionCentral.add(boton9);
        seccionCentral.add(EtiquetaVacia);
        seccionCentral.add(boton0);
        //Finalmente, introducimos el contenedor entero en la parte CENTRO.
        cpane.add(seccionCentral, BorderLayout.CENTER); //No añadimos un elemento en la parte central, sino un contenedor entero.
        //En la parte ESTE introduciré los botones de operacion (+,-,=, etc), para ello crearé un nuevo contenedor.
        JPanel seccionEste = new JPanel();
        seccionEste.setLayout(new GridLayout(6,1));
        seccionEste.add(botonMasMenos);
        seccionEste.add(botonMas);
        seccionEste.add(botonMenos);
        seccionEste.add(botonPor);
        seccionEste.add(botonEntre);
        seccionEste.add(botonIgual);
        cpane.add(seccionEste, BorderLayout.EAST);
        
        //Ahora hay que hacer la acción a cada botón. Para ello hay que poner los botones en modo escucha esperando a que sean pulsados.
        boton1.addActionListener(this);
        boton2.addActionListener(this);
        boton3.addActionListener(this);
        boton4.addActionListener(this);
        boton5.addActionListener(this);
        boton6.addActionListener(this);
        boton7.addActionListener(this);
        boton8.addActionListener(this);
        boton9.addActionListener(this);
        boton0.addActionListener(this);
        botonCE.addActionListener(this);
        botonMas.addActionListener(this);
        botonMenos.addActionListener(this);
        botonPor.addActionListener(this);
        botonEntre.addActionListener(this);
        botonIgual.addActionListener(this);
        botonMasMenos.addActionListener(this);

        //Finalmente empaquetamos y lo hacemos visible.
        ventana.pack();
        ventana.setVisible(true);
        
        //Código para que al pulsar la X se cierre el programa.
        ventana.addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent evt ) {
                System.exit( 0 );
            }
        }); 
    }
    //Método que realiza operaciones según el botón pulsado.
    public void actionPerformed(ActionEvent Accion){
        if (Accion.getSource() == boton1){
            Texto += 1;
        }
        if (Accion.getSource() == boton2){
            Texto += 2;
        }
        if (Accion.getSource() == boton3){
            Texto += 3;
        }
        if (Accion.getSource() == boton4){
            Texto += 4;
        }
        if (Accion.getSource() == boton5){
            Texto += 5;
        }
        if (Accion.getSource() == boton6){
            Texto += 6;
        }
        if (Accion.getSource() == boton7){
            Texto += 7;
        }
        if (Accion.getSource() == boton8){
            Texto += 8;
        }
        if (Accion.getSource() == boton9){
            Texto += 9;
        }
        if (Accion.getSource() == boton0){
            if ((Texto != "") || (operador != "")){
                Texto += 0;
            }
        }
        if (Accion.getSource() == botonMasMenos){
            if (Texto != ""){
                MasMenos = Double.parseDouble(Texto);
                MasMenos = -MasMenos;
                Texto = String.valueOf(MasMenos);
            }
        }
        if (Accion.getSource() == botonCE){
            Texto = "";
            operador = "";
        }
        if (Accion.getSource() == botonIgual){
            operando2 = Double.parseDouble(Resultado.getText());
            if (operador == "+"){
                Texto = String.valueOf(operando1 + operando2);
            }
            if (operador == "-"){
                Texto = String.valueOf(operando1 - operando2);
            } 
            if (operador == "*"){
                Texto = String.valueOf(operando1 * operando2);
            } 
            if (operador == "/"){
                Texto = String.valueOf(operando1 / operando2);
            } 
        }
        Resultado.setText(Texto); 
        if (Accion.getSource() == botonMas){
            operando1 = Double.parseDouble(Resultado.getText());
            operador = "+";
            Texto = "";    
        }
        if (Accion.getSource() == botonMenos){
            operando1 = Double.parseDouble(Resultado.getText());
            operador = "-";
            Texto = "";    
        }
        if (Accion.getSource() == botonPor){
            operando1 = Double.parseDouble(Resultado.getText());
            operador = "*";
            Texto = "";    
        }
        if (Accion.getSource() == botonEntre){
            operando1 = Double.parseDouble(Resultado.getText());
            operador = "/";
            Texto = "";    
        }
    }
}