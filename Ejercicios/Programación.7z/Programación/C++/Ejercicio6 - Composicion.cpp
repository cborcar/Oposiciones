/***********************************************************************************/
/*************************** EJERCICIO COMPOSICI�N 4 C++ ***************************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************
Queremos crear un programa para gestionar un videoclub, para ello vamos a hacer
una clase que represente una pel�cula. De las pel�culas, vamos a guardar un
c�digo, un nombre, un genero y la cantidad de discos que tenemos. El c�digo
debe empezar con la palabra "DVD". La cantidad debe ser mayor que 0. Vamos a
crear los siguientes m�todos:
      - Constructores.
      - M�todos de devoluci�n y modificaci�n.
      - M�todos toString que devuelve una cadena con informaci�n de la pel�cula.
      - Indicar_venta: Decrementa la cantidad de discos. Si la cantidad es 0
        no se puede decrementar y se debe indicar un mensaje de que no se puede
        vender.
Despu�s, crea la clase videoclub, en la que vamos a tener 2 atributos: el nombre
del videoclub y un conjunto de pel�culas. Vamos a tener los siguientes m�todos:
      - Un constructor.
      - A�adir_pel�cula: Lee los datos de una pel�cula y lo introduce en el vector.
      - Borra_pel�cula: Pide el c�digo de una pel�cula y si lo encuentra lo borra.
      - Listar_pel�culas: Lista todas las pel�culas.
      - Buscar_pel�culas: Me pregunta por que atributo quiero buscar (por c�digo,
        por nombre, por g�nero o por cantidad).
      - Vender: Pide el c�digo de una pel�cula y si est� en el vector se
        decrementa la cantidad de discos. 
      - Mostrar_pel�culas_que_faltan: Muestra las pel�culas cuya cantidad es 0.
Crear un programa principal que muestre un men� que permita gestionar el videoclub.*/

/***********************************************************************************/
/******************************** LIBRER�AS Y CLASES *******************************/
/***********************************************************************************/
#include <iostream>
#define NumPeliculas 10
using namespace std;

//CLASE PEL�CULA.
class Pelicula{
      //Atributos.
      private:
              string Codigo;
              string Nombre;
              string Genero;
              int Cantidad;
      //M�todos.        
      public:
             //Constructor por defecto.
             Pelicula (){};
             //Constructor que recibe 4 par�metros.
             Pelicula (const string &Codigo, const string &Nombre, const string &Genero, int Cantidad){
                      this->Codigo = Codigo;
                      this->Nombre = Nombre;
                      this->Genero = Genero;
                      this->Cantidad = Cantidad;
             };
             //Destructor.
             ~Pelicula (){};
             //METODOS DE DEVOLUCI�N.
             //M�todo para acceder a c�digo
             string getCodigo(){
                    return Codigo;
             }
             //M�todo para acceder a nombre;
             string getNombre(){
                    return Nombre;
             }
             //M�todo para acceder a genero;
             string getGenero(){
                    return Genero;
             }
             //M�todo para acceder a cantidad;
             int getCantidad(){
                    return Cantidad;
             }           
             //METODOS DE MODIFICACI�N.
             //M�todo para escribir en c�digo
             void setCodigo(const string &Codigo){
                    this->Codigo = Codigo;
             }
             //M�todo para acceder a nombre;
             void setNombre(const string &Nombre){
                    this->Nombre = Nombre;
             }
             //M�todo para acceder a genero;
             void setGenero(const string &Genero){
                    this->Genero = Genero;
             }
             //M�todo para acceder a cantidad;
             void setCantidad(int Cantidad){
                    this->Cantidad = Cantidad;
             }             
             
             //M�TODO TOSTRING
             string toString (){
                 //   string CantidadCaracter = itoa (Cantidad_.c_str());
                    string Cadena = Codigo;
                    Cadena += ": ";
                    Cadena += Nombre;
                    Cadena += ", ";
                    Cadena += Genero;
                    Cadena += ", ";
                   // Cadena += Cantidad_; //Lo pongo entre comentarios porque me pasa valores raros
                    return Cadena;   
             }  
             //M�TODO INDICAR_VENTA.  
             void Indicar_venta(){
                  if (Cantidad > 0){
                         Cantidad -= 1;
                         cout << endl << "Venta realizada.";                    
                  }
                  else{
                       cout << endl << "No se puede vender ya que no hay existencias.";    
                  } 
             }       
};

//CLASE VIDEOCLUB.
class Videoclub{
      private:
              string Nombre;
              Pelicula Peliculas[NumPeliculas];            
      public:
             //Constructor.
             Videoclub(const string &Nom){
                   Nombre = Nom; //No se llama nombre, no hace falta this.
             };
             //Destructor.
             ~Videoclub(){};
             //M�todo para acceder al nombre.
             string getNombre(){
                    return Nombre;
             }
             //M�todo A�adir_pel�cula.
             void Anadir_pelicula (const string &Codigo, const string &Nombre, const string &Genero, int Cantidad){
                  int i = 0;
                  Pelicula PeliculaAIngresar(Codigo,Nombre,Genero,Cantidad);
                  while (Peliculas[i].getCodigo() != ("")){ //Buscamos un hueco libre y nos posicionamos.
                        i++;
                  }
                  Peliculas[i] = PeliculaAIngresar;                       
             }
             //M�todo Borrar pelicula.
             void Borrar_pelicula(){
                  string Codigo;
                  int i = 0, j = 0, eliminado = 0, Repite = 0;
                  
                  if (Peliculas[0].getCodigo() == ("")){
                          cout << endl << "No hay peliculas ingresadas.";                                       
                  }
                  else
                  {
                      while (Repite == 0){
                             cout << endl << "Introduce el codigo de pelicula: ";
                             cin >> Codigo;
                             if ((Codigo[0] == 'D') && (Codigo[1] == 'V') && (Codigo[2] == 'D')){
                                 Repite = 1;                     
                             }
                             else{
                                 cout << endl << "El codigo debe empezar por 'DVD', intentalo de nuevo.";
                                 getchar();
                                 getchar();
                             }                        
                       }
                       while (Peliculas[i].getCodigo() != ("")){ 
                                if (Peliculas[i].getCodigo() == Codigo){ 
                                        j = i;
                                        //Movemos todos los posteriores una posici�n atr�s sobreescribiendo el contacto a borrar.
                                        while (Peliculas[j].getCodigo() != ("")){
                                              Peliculas[j].setCodigo(Peliculas[j+1].getCodigo());
                                              Peliculas[j].setNombre(Peliculas[j+1].getNombre());
                                              Peliculas[j].setGenero(Peliculas[j+1].getGenero());
                                              Peliculas[j].setCantidad(Peliculas[j+1].getCantidad());
                                              j++;  
                                        }
                                        eliminado += 1;
                                        i--;
                                }
                                i++; 
                       }
                       if (eliminado > 0){
                                cout << endl << "Se han eliminado " << eliminado << " peliculas.";        
                       }
                       else{
                                cout << endl << "No existen peliculas con ese codigo.";
                       }
                  }
                  getchar();
                  getchar();
                  cout << endl; 
             }
             //M�todo Listar_pel�culas.
             void Listar_peliculas (){
                  int i = 0;
                  if (Peliculas[0].getCodigo() == ("")){
                          cout << endl << "No hay peliculas ingresadas.";                                     
                  }
                  else
                  {
                      while (Peliculas[i].getCodigo() != ("")){
                            cout << endl << Peliculas[i].toString() << Peliculas[i].getCantidad();
                            i++;
                      }      
                  }
                  getchar();
                  getchar(); 
                  cout << endl; 
             }
             //M�todo Buscar_Peliculas.
             void Buscar_peliculas(){
                  int opcion2 = 0, i = 0, Cantidad, Encontrado, Repite;
                  string Cadena;
                  if (Peliculas[0].getCodigo() == ("")){
                          cout << endl << "No hay peliculas ingresadas."; 
                          getchar();
                          getchar();
                          cout << endl;                                      
                  }
                  else{
                       system ("cls");
                       while (opcion2 != 5){
                             cout << "VIDEOCLUB: "<< getNombre() << endl << endl;
                             cout << "Opcion 1: Buscar por Codigo." << endl;
                             cout << "Opcion 2: Buscar por Nombre." << endl;
                             cout << "Opcion 3: Buscar por Genero." << endl;
                             cout << "Opcion 4: Buscar por Cantidad." << endl;
                             cout << "Opcion 5: Volver atras." << endl << endl;
                             cout << "Elige una opcion: ";
                             cin >> opcion2;
                             switch (opcion2){
                                    //Opci�n 1: Buscar por C�digo.
                                    case 1:
                                         Encontrado = 0;
                                         i = 0;
                                         Repite = 0;
                                         while (Repite == 0){
                                               cout << endl << "Introduce el codigo de pelicula: ";
                                               cin >> Cadena;
                                               if ((Cadena[0] == 'D') && (Cadena[1] == 'V') && (Cadena[2] == 'D')){
                                                       Repite = 1;                     
                                               }
                                               else{
                                                       cout << endl << "El codigo debe empezar por 'DVD', intentalo de nuevo.";
                                                       getchar();
                                                       getchar();
                                               }                        
                                         }
                                         while (Peliculas[i].getCodigo() != ("")){
                                               if (Peliculas[i].getCodigo() == Cadena){
                                                       cout << endl << Peliculas[i].toString() << Peliculas[i].getCantidad();
                                                       Encontrado = 1;                       
                                               }
                                               i++;
                                         }
                                         if (Encontrado == 0){
                                                        cout << endl << "No se han encontrado peliculas con ese nombre.";            
                                         }
                                         getchar();
                                         getchar();
                                         cout << endl;
                                    break;
                                    //Opci�n 2: Buscar por Nombre.
                                    case 2:
                                         Encontrado = 0;
                                         i = 0;
                                         cout << endl << "Introduce un nombre: ";
                                         cin >> Cadena;
                                         while (Peliculas[i].getCodigo() != ("")){
                                               if (Peliculas[i].getNombre() == Cadena){
                                                       cout << endl << Peliculas[i].toString() << Peliculas[i].getCantidad();
                                                       Encontrado = 1;                       
                                               }
                                               i++;
                                         }
                                         if (Encontrado == 0){
                                                        cout << endl << "No se han encontrado peliculas con ese nombre.";            
                                         }
                                         getchar();
                                         getchar();
                                         cout << endl;
                                    break;
                                    //Opci�n 3: Buscar por Genero.
                                    case 3:
                                         Encontrado = 0;
                                         i = 0;
                                         cout << endl << "Introduce el genero: ";
                                         cin >> Cadena;
                                         while (Peliculas[i].getCodigo() != ("")){
                                               if (Peliculas[i].getGenero() == Cadena){
                                                       cout << endl << Peliculas[i].toString() << Peliculas[i].getCantidad();
                                                       Encontrado = 1;                       
                                               }
                                               i++;
                                         }
                                         if (Encontrado == 0){
                                                        cout << endl << "No se han encontrado peliculas de ese genero.";            
                                         }
                                         getchar();
                                         getchar();
                                         cout << endl;
                                    break;
                                    //Opci�n 4: Buscar por Cantidad.
                                    case 4:
                                         Cantidad = -1;
                                         Encontrado = 0;
                                         i = 0;
                                         while (Cantidad < 0){
                                               cout << endl << "Introduce la cantidad de peliculas: ";
                                               cin >> Cantidad;
                                               if (Cantidad < 0){
                                                            cout << endl << "La cantidad debe de ser superior o igual a 0, intentalo de nuevo.";
                                                            getchar();
                                                            getchar();
                                                            cout << endl;
                                               }
                                         }
                                         while (Peliculas[i].getCodigo() != ("")){
                                               if (Peliculas[i].getCantidad() == Cantidad){
                                                       cout << endl << Peliculas[i].toString() << Peliculas[i].getCantidad();
                                                       Encontrado = 1;                       
                                               }
                                               i++;
                                         }
                                         if (Encontrado == 0){
                                                        cout << endl << "No se han encontrado peliculas con esa cantidad.";            
                                         }
                                         getchar();
                                         getchar();
                                         cout << endl;                                  
                                    break;
                                    //Opci�n 5: Volver atr�s.
                                    case 5:
                                         system ("cls");
                                    break;
                                    //Caso Cualquiera: Muestra error.
                                    default:
                                            cout << endl << "Opcion invalida, vuelve a intentarlo." << endl;
                                            getchar();
                                            getchar();
                                            break;     
                             }    
                       }
                  }
             }                        
                              
             //M�todo Vender.
             void Vender(){
                  string Codigo;
                  int i = 0, encontrado = 0, Repite = 0;
                  
                  if (Peliculas[0].getCodigo() == ("")){
                          cout << endl << "No hay peliculas ingresadas.";                                       
                  }
                  else{
                       while (Repite == 0){
                             cout << endl << "Introduce el codigo de pelicula: ";
                             cin >> Codigo;
                             if ((Codigo[0] == 'D') && (Codigo[1] == 'V') && (Codigo[2] == 'D')){
                                 Repite = 1;                     
                             }
                             else{
                                 cout << endl << "El codigo debe empezar por 'DVD', intentalo de nuevo.";
                                 getchar();
                                 getchar();
                             }                        
                       }
                          while ((Peliculas[i].getCodigo() != ("")) && (encontrado == 0)){
                                if (Peliculas[i].getCodigo() == Codigo){
                                      Peliculas[i].Indicar_venta();                       
                                      encontrado = 1;                       
                                }
                                i++;
                          }
                          if (encontrado == 0){
                                cout << endl << "No se han encontrado peliculas con ese codigo.";            
                          } 
                  }
                  getchar();
                  getchar(); 
                  cout << endl;                  
             }
             //M�todo Mostrar_peliculas_que_faltan
             void Mostrar_peliculas_que_faltan(){
                  int i = 0, existen = 0;
                  
                  if (Peliculas[0].getCodigo() == ("")){
                          cout << endl << "No hay peliculas ingresadas.";                                       
                  }
                  else{
                          while (Peliculas[i].getCodigo() != ("")){
                               if (Peliculas[i].getCantidad() == 0){
                                      cout << endl << Peliculas[i].toString() << Peliculas[i].getCantidad();
                                      existen = 1;                       
                                }
                                i++;
                          }
                          if (existen == 0){
                                cout << endl << "No se han encontrado peliculas cuya cantidad es 0.";            
                          } 
                  }
                  getchar();
                  getchar(); 
                  cout << endl;                 
             }   
};

int main(){
    Videoclub Videoclub("El Planeta de los videos");
    int opcion, Cantidad = -1, Repite = 0;
    string Codigo, Nombre, Genero;
    
    while (opcion != 7){
          cout << "VIDEOCLUB: "<< Videoclub.getNombre() << endl << endl;
          cout << "Opcion 1: Introducir una pelicula." << endl;
          cout << "Opcion 2: Borrar una pelicula." << endl;
          cout << "Opcion 3: Listar las peliculas." << endl;
          cout << "Opcion 4: Buscar una pelicula." << endl;
          cout << "Opcion 5: Vender una pelicula." << endl;
          cout << "Opcion 6: Mostrar peliculas que faltan." << endl;
          cout << "Opcion 7: Salir del programa." << endl << endl;
          cout << "Escoge una opcion: ";
          cin >> opcion;
          switch (opcion){
                 //Opci�n 1: Introducir una pelicula.
                 case 1:
                      Repite = 0;
                      Cantidad = 0;
                      while (Repite == 0){
                            cout << endl << "Introduce el codigo de pelicula: ";
                            cin >> Codigo;
                            if ((Codigo[0] == 'D') && (Codigo[1] == 'V') && (Codigo[2] == 'D')){
                                 Repite = 1;                     
                            }
                            else{
                                 cout << endl << "El codigo debe empezar por 'DVD', intentalo de nuevo.";
                                 getchar();
                                 getchar();
                            }                        
                      }
                      cout << endl << "Introduce el nombre de la pelicula: ";
                      cin >> Nombre;
                      cout << endl << "Introduce el genero de la pelicula: ";
                      cin >> Genero;  
                      while (Cantidad <= 0){
                            cout << endl << "Introduce la cantidad de peliculas: ";
                            cin >> Cantidad;
                            if (Cantidad <= 0){
                                  cout << endl << "La cantidad debe de ser superior a 0, intentalo de nuevo.";
                                  getchar();
                                  getchar();
                            }
                      }
                      Videoclub.Anadir_pelicula(Codigo, Nombre, Genero, Cantidad);
                      cout << endl << "Pelicula insertada." << endl;
                      getchar();
                      getchar();                                           
                 break;
                 //Opci�n 2: Borra Pelicula
                 case 2:
                      Videoclub.Borrar_pelicula();
                 break;
                 //Opci�n 3: Listar pel�culas
                 case 3:
                      Videoclub.Listar_peliculas();
                 break;
                 //Opci�n 4: Buscar Peliculas
                 case 4:
                      Videoclub.Buscar_peliculas();
                 break;
                 //Opci�n 5: Vender peliculas
                 case 5:
                      Videoclub.Vender();
                 break;
                 //Opci�n 6: Mostrar las peliculas cuya cantidad es 0.
                 case 6:
                      Videoclub.Mostrar_peliculas_que_faltan();
                 break;
                 //Caso 7: Salir del programa.                 
                 case 7:
                 break;
                 //Caso Cualquiera: Muestra error.
                 default:
                         cout << endl << "Opcion invalida, vuelve a intentarlo." << endl;
                         getchar();
                         getchar();                         
                 break;                
                 
          }    
    }   
}
