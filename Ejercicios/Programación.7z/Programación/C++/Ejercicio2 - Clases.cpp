/***********************************************************************************/
/****************************** EJERCICIO CLASES 1 C++ *****************************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************
EXPLICACI�N: En C se crean estructuras y se acceden a ellas con funciones y/o
procedimientos. En C++ se utilizan clases que son como estructuras y poseen m�todos
que son como las funciones de C. Ejemplo:
    
Realizar la implementaci�n de la siguiente clase Punto. A parte, a�ade un m�todo que 
sume 2 puntos y devuelva otro nuevo la suma de los 2:
   class Punto{
      private:
           float x_;
           float y_;
      public:
           Punto (float = 0, float = 0);
               void mostrar () const; //Visualiza (x,y) en la pantalla.
               void x(float x); //Cambia la coordenada x.
               void y(float y); //Cambia la coordenada y.
               void cambiar (float x, float y); //Cambia ambas coordenadas.
               void transladar(float desplazamiento); //Suma desplazamiento a cada coordenada.
               float x() const; //Devuelve la coordenada X.
               float y() const; //Devuelve la coordenada Y.
       }*/
   
/***********************************************************************************/
/******************************** LIBRER�AS Y CLASES *******************************/
/***********************************************************************************/   
#include <iostream>

using namespace std; //Esto se pone siempre.

//DEFINIMOS LA CLASE PUNTO.
class Punto{
      //DEFINIMOS LOS ATRIBUTOS.
      private: //Lo normal es declarar los atributos como privado para que no puedan acceder a ellos nadie.
              float x_;
              float y_;
      //DEFINIMOS LOS M�TODOS.
      public: //Los m�todos como p�blicos, ya que es donde queremos acceder.
             //Declaramos un Constructor. Los constructores tienen el mismo nombre que la clase y se pueden o no declarar, sirven para darles valores inicialmente a la hora de declarar un objeto.
             Punto (float x = 0, float y = 0){
                   this->x_ = x;  //Como x_ y x se llaman distinto no hace falta poner "this" para distinguirlos, si se llamaran igual entonces s�, siendo el this el atributo de la clase.
                   y_ = y;
             }
             //Declaramos un Destructor. Destruyen el objeto.
             ~Punto(){}
             //M�todo de devoluci�n de la coordenada X. El atributo x_ es privado, as� que no se puede acceder poniendo Objeto1.x_ como en C, si fuera p�blico entonces s�. Para acceder a �l hay que a�adir un m�todo que nos devuelva el valor y se accede llamando a �se m�todo de forma: Objeto1.x().
             float x() const{
                   return x_;
             }
             //M�todo de devoluci�n de la coordenada Y.
             float y() const{
                   return y_;
             }
             //M�todo que visualiza (x,y) en la pantalla.
             void mostrar () const {
                  cout << "El valor del punto es: (" << x_ << "," << y_ << ")" << endl;
             }
             //M�todo modificaci�n de la coordenada X. Tampoco podemos modificar el atributo de forma: Objeto1.x_ = 3 como en C ya que es privado. Se crea un m�todo que recibe un par�metro y lo modifica. Por ejemplo: Objeto1.x(3).   
             void x(float x){
                  x_ = x;
             }
             //M�todo de modificaci�n de la coordenada Y.     
             void y(float y){
                  y_ = y;
             }
             //M�todo de modificaci�n de ambas coordenadas.      
             void cambiar (float x, float y){
                  x_ = x;
                  y_ = y;
             } 
             //M�todo que suma un desplazamiento a cada coordenada.     
             void transladar(float desplazamiento){
                  x_ += desplazamiento;
                  y_ += desplazamiento;
             }
             //M�todo que sume 2 puntos y devuelve la suma.
             Punto suma (Punto a, Punto b){                  
                   x_ += a.x_ + b.x_;
                   y_ += a.y_ + b.y_;
             }
};

/***********************************************************************************/
/**************************** INICIO DEL PROGRAMA **********************************/
/***********************************************************************************/
int main (){    

     Punto Punto1(3,2); //Creamos el objeto Punto1 de la clase Punto utilizando el constructor y d�ndole valores iniciales 3 y 2.
     Punto Punto2(10,20);
     Punto Punto3(0,0);
     Punto1.mostrar();  //Llama al m�todo mostrar del punto1.
     Punto1.x(5); //Llama al m�todo x(float x), que hace que Punto1.x = 5.
     Punto1.y(6);
     Punto1.mostrar();
     Punto1.cambiar (6,7);
     Punto1.mostrar();
     Punto1.transladar(5);
     Punto1.mostrar();
     Punto3.suma(Punto1, Punto2);
     Punto3.mostrar();
     getchar();
}
