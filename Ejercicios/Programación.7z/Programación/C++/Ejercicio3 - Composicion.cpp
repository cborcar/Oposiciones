/***********************************************************************************/
/*************************** EJERCICIO COMPOSICI�N 1 C++ ***************************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************
EXPLICACI�N: Composici�n es cuando un atributo de una clase tiene un tipo de otra clase.
Por ejemplo: En el ejercicio anterior se vi� la clase punto, una clase rect�ngulo
tiene como atributos 4 atributos de tipo Punto. Ejemplo:

Realizar la implementaci�n de la clase Rect�ngulo que contiene cuatro puntos
para definir sus v�rtices. Estos puntos deben ser atributos din�micos, es decir,
cada v�rtice es un puntero a un objeto de tipo punto. Debe haber un m�todo
"mostrar" que muestre las coordenadas del rect�ngulo por pantalla. La clase
rect�ngulo debe disponer de un constructor por defecto y otro que reciba cuatro
puntos como par�metros. Utiliza el siguiente c�digo para probar que funciona:
         int main()
         {
             Rectangulo r1;
             Rectangulo r2(2,3);
             Punto p1(1,1), p2(2,1), p3(2,3), p4(1,3);
             Rectangulo r3(p1,p2,p3,p4);
             r1 = r2;
             r1.mostrar();
             r2.mostrar();
         }*/
   
/***********************************************************************************/
/******************************** LIBRER�AS Y CLASES *******************************/
/***********************************************************************************/   
#include <iostream>

using namespace std;      

//DEFINIMOS LA CLASE PUNTO.
class Punto{
      //DEFINIMOS LOS ATRIBUTOS.
      private:
              float x_;
              float y_;
      //DEFINIMOS LOS M�TODOS.
      public:
             //Constructor.
             Punto (float x = 0, float y = 0){
                   x_ = x;
                   y_ = y;
             }
             //Destructor.
             ~Punto(){}
             //M�todo de devoluci�n de la coordenada X.
             float x() const{
                   return x_;
             };
             //M�todo de devoluci�n de la coordenada Y.
             float y() const{
                   return y_;
             };
             //M�todo que visualiza (x,y) en la pantalla.
             void mostrar () const {
                  cout << "(" << x_ << "," << y_ << ") ";
                  }
             //M�todo modificaci�n de la coordenada X.     
             void x(float x){
                  x_ = x;
                  }
             //M�todo de modificaci�n de la coordenada Y.     
             void y(float y){
                  y_ = y;
                  }
             //M�todo de modificaci�n de ambas coordenadas.      
             void cambiar (float x, float y){
                  x_ = x;
                  y_ = y;
                  } 
             //M�todo que suma un desplazamiento a cada coordenada.     
             void transladar(float desplazamiento){
                  x_ += desplazamiento;
                  y_ += desplazamiento;
                  }
             //M�todo que devuelve la distancia entre dos coordenadas de un punto.
             float distancia (Punto) const{
                   //hacerlo luego.
             }
             //M�todo que sume 2 puntos y devuelve la suma.
             Punto suma (Punto a, Punto b){                  
                   x_ += a.x_ + b.x_;
                   y_ += a.y_ + b.y_;
             }
};

//DEFINIMOS LA CLASE RECTANGULO.
class Rectangulo
{
      //DEFINIMOS LOS ATRIBUTOS.
      private:
              Punto *p1, *p2, *p3, *p4; //p1 es un puntero de tipo Punto.
      //DEFINIMOS LOS M�TODOS.
      public:
             //Constructor por defecto. Quiere decir que le pone el valor 0 a todos sus atributos.
             Rectangulo (){}
             //Constructor cuando recibe 2 atributos.
             Rectangulo (float x, float y){
                  p1 = new (nothrow) Punto; //Como son punteros, creamos el nodo al que apunta, si no lo fueran no hace falta.
                  p2 = new (nothrow) Punto; //El nothrow no es necesario, se pone para que si no hay memoria suficiente sea nulo.
                  p3 = new (nothrow) Punto;
                  p4 = new (nothrow) Punto;
                  Punto pp1(x,y);
                  Punto pp2(0,0);
                  Punto pp3(0,0);
                  Punto pp4(0,0);
                  *p1 = pp1;
                  *p2 = pp2;
                  *p3 = pp3;
                  *p4 = pp4;      
             }
             //Constructor cuando recibe 4 atributos.
             Rectangulo (Punto pp1, Punto pp2, Punto pp3, Punto pp4){
                  p1 = new (nothrow) Punto;
                  p2 = new (nothrow) Punto;
                  p3 = new (nothrow) Punto;
                  p4 = new (nothrow) Punto;
                  *p1 = pp1;
                  *p2 = pp2;
                  *p3 = pp3;
                  *p4 = pp4;     
             }
             //Destructor.
             ~Rectangulo(){ //Si utilizamos punteros aqu� se borran, si no, se escribe un destructor vac�o.
                  delete p1;
                  delete p2;
                  delete p3;
                  delete p4;
             };
             //M�todo mostrar.
             void mostrar(){
                  (*p1).mostrar(); //Llama al m�todo mostrar() de la clase punto.
                  (*p2).mostrar();
                  (*p3).mostrar();
                  (*p4).mostrar();                
             }
};

/***********************************************************************************/
/**************************** INICIO DEL PROGRAMA **********************************/
/***********************************************************************************/
int main (){
    Rectangulo r1; //Creamos el objeto r1 de la clase rect�ngulo utilizando el constructor por defecto, es decir, todos sus atributos a 0.
    Rectangulo r2(2,3); //Creamos el objeto r2 utilizando el constructor 2 donde pone un punto como (2,3) y el resto como 0.
    Punto p1(1,1), p2(2,1), p3(2,3), p4(1,3); //Creamos 4 objetos punto.
    Rectangulo r3(p1,p2,p3,p4); //Creamos el objeto r3 d�ndole valores a todos sus puntos.
    r1 = r2;
    r1.mostrar();
    cout << endl; //endl es como printf("\n");
    r2.mostrar();
    cout << endl;
    r3.mostrar();
    getchar();
}
