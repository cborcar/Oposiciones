/***********************************************************************************/
/***************************** EJERCICIO HERENCIA 2 C++ ****************************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************
EXPLICACI�N: En los ejercicios anteriores, los objetos se han creado est�ticamente pero
lo m�s com�n es hacerlo din�micamente (con punteros). Si se crean din�micamente, se
hereda y se sobreescribe un m�todo, no se produce polimorfismo, es decir, que se
ejecutar� la del padre aunque est� sobreescrita en la hija. Para crear polimorfismo en
objetos din�micos, se tienen que crear los m�todos del padre que est�n definidos en la
hija como virtuales, de forma que si es virtual mirar� primero si lo tiene definido
la hija, ejecut�ndose si lo tiene en ella. Ejemplo:
             
Implementar el ejercicio anterior haciendo uso de objetos din�micos.  
             
/***********************************************************************************/
/******************************** LIBRER�AS Y CLASES *******************************/
/***********************************************************************************/  
#include <iostream>
using namespace std;

//CLASE CUENTA.
class Cuenta{
      //Atributos.
      protected:
              string Titular;
              double Saldo;
      //M�todos.
      public:
             //Constructor por defecto.
             Cuenta (){}
             //Constructor que recibe 2 atributos;
             Cuenta (const string &Titular, double Saldo){
                    this->Titular = Titular;
                    this->Saldo = Saldo;
             }
             //M�todo de devoluci�n de Titular.
             string getTitular(){
                    return Titular;
             }
             //M�todo de devoluci�n de Saldo.
             double getSaldo(){
                    return Saldo;
             }
             //M�todo de modificaci�n de Titular.
             void setTitular (const string &Titular){
                    this->Titular = Titular;
             }
             //M�todo de modificaci�n de Saldo. 
             void setSaldo (double Saldo){
                    this->Saldo = Saldo;  
             }
             //M�todo Reintegro. Se pone virtual por si se sobreescribe en el hijo para que se ejecute la del hijo antes que esta.
             virtual void Reintegro (double Cantidad){
                  if (Saldo == 0){
                            Saldo -= Cantidad;
                  }
                  else{
                       cout << endl << "No se puede sacar dinero de la cuenta porque no tiene suficiente." << endl;
                  }
             }
             //M�todo Ingreso.
             virtual void Ingreso (double Cantidad){
                  Saldo += Cantidad;
             }
             //M�todo toString.
             virtual string toString (){
                    string Cadena;
                    Cadena += "Titular: ";
                    Cadena += Titular;
                    Cadena += ", Saldo: ";
       //             Cadena += Saldo;
                    return Cadena;   
             } 
};

//CLASE CUENTA DE CR�DITO HIJA DE LA CLASE CUENTA.
class CuentaCredito : public Cuenta{ //Hereda de la clase Cuenta.
      public:
             //Se ha de definir un constructor.
             CuentaCredito (const string &Titular, double Saldo) : Cuenta (Titular, Saldo){}
             //Utilizamos el polimorfismo en el m�todo Reintegro.
             void Reintegro (double Cantidad){
                  Saldo -= Cantidad;
                  if (Saldo < 0){
                            Saldo -= Cantidad * 0.01;
                  }
             } 
};

//CLASE CUENTA DE N�MINA.
class CuentaNomina : public Cuenta{
      private:
             double Nomina;
      public:
             //Constructor
             CuentaNomina (const string &Titular, double Saldo, double Nomina) : Cuenta(Titular, Saldo){
                           this->Nomina = Nomina; //Cuenta inicializa Titular y Saldo pero no Nomina, los atributos propios se ponen como siempre.
             }
             //M�todo Registro.             
             void Reintegro (double Cantidad){
                 if ((Saldo - Cantidad) >= (0 - Nomina)){
                            Saldo -= Cantidad;           
                 }
                 else{
                      cout << "No se puede hacer reintegro, se quedaria un saldo negativo mayor a la nomina." << endl << endl;
                      
                 }
             }
};

//CLASE CUENTA DE AHORRO.
class CuentaAhorro : public Cuenta{
      public:
             //Constructor.
             CuentaAhorro (const string &Titular, double Saldo) : Cuenta (Titular, Saldo){}
             //M�todo Ingreso.             
             void Ingreso (double Cantidad){
                  Saldo += Cantidad * 1.01;
             }
};

//CLASE CUENTA JOVEN.      
class CuentaJoven : public Cuenta{
      private:
              int Edad;
      public:
             //Constructor
             CuentaJoven (const string &Titular, double Saldo, int Edad) : Cuenta (Titular, Saldo){
                         this->Edad = Edad;   
             }    
             //M�todo Reintegro.
             void Reintegro (double Cantidad){
                  if (Edad <= 25){
                           if (Saldo == 0){
                                     Saldo -= Cantidad;
                           }
                           else{
                                     cout << endl << "No se puede sacar dinero de la cuenta porque no tiene suficiente." << endl;
                           }
                  }
                  else{
                       cout << endl << "No se pueden realizar operaciones, la edad es mayor a 25." << endl;
                  }
             }
             //M�todo Ingreso.
             void Ingreso (double Cantidad){
                  if (Edad <= 25){                  
                           Saldo += Cantidad;
                  }
                  else{
                       cout << endl << "No se pueden realizar operaciones, la edad es mayor a 25." << endl;
                  }                  
             }
};      


/***********************************************************************************/
/**************************** INICIO DEL PROGRAMA **********************************/
/***********************************************************************************/
int main(){
    Cuenta *Credito = new CuentaCredito("Juan",100); //Se crea el objeto como puntero
    //Tambien se puede crear as�: CuentaCredito *Credito = new CuentaCredito("Juan",100);, pero en el ejercicio siguiente se ver� porque a veces es aconsejable declararlo de la clase padre.
    Cuenta *Nomina = new CuentaNomina("Juan",100, 100);
    Cuenta *Ahorro = new CuentaAhorro("Juan",100);
    Cuenta *Joven = new CuentaJoven ("Juan",100, 25);    
    cout << "CUENTA DE CREDITO:" << endl << endl;
    Credito->Ingreso (50); //No se pone Credito.Ingreso sino con la flecha porque son punteros.
    Credito->Reintegro (200);
    cout << "Saldo: " << Credito->getSaldo() << endl;
    cout << endl << "CUENTA DE NOMINA:" << endl << endl;    
    Nomina->Ingreso (50);
    Nomina->Reintegro (200);    
    cout << "Saldo: " << Nomina->getSaldo() << endl; 
    cout << endl << "CUENTA DE AHORRO:" << endl;        
    Ahorro->Ingreso (50);
    Ahorro->Reintegro (200);
    cout << endl << "Saldo: " << Ahorro->getSaldo() << endl; 
    cout << endl << "CUENTA JOVEN:" << endl;        
    Joven->Ingreso (50);
    Joven->Reintegro (200);
    cout << endl << "Saldo: " << Joven->getSaldo() << endl;                 
    getchar();
    getchar();
    delete Credito; //Los punteros han de borrarse.
    delete Nomina;
    delete Ahorro;
    delete Joven;         
    getchar();
    getchar();
    
}
