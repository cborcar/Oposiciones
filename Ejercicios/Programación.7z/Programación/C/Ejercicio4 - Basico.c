/***********************************************************************************/
/******************************** EJERCICIO C B�SICO *******************************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************
Crea un programa en C que lea 3 numeros (grados) e indique el tipo de tri�ngulo que 
forman (is�sceles, equil�tero, escaleno). Comprobar que los n�meros realmente formen 
un tri�ngulo, si no emitir un error. Al terminar tiene que preguntar si se desea 
escribir otro tri�ngulo pudiendo responder S o N.*/

#include <stdio.h>

int main(){
	int x, y, z;
	char opcion = 's';
	
	while (opcion == 's' || opcion == 'S'){
		system ("cls");
		printf("Introduce el primer grado: ");
		scanf("%d", &x);
		printf("\nIntroduce el segundo grado: ");
		scanf("%d", &y);
		printf("\nIntroduce el tercer grado: ");
		scanf("%d", &z);
	
		if (x+y+z != 180)
			printf("\nError, la suma de los grados tiene que ser 180, prueba otra vez.");
		else{
			if (x==60 && y==60 && z==60) //Comprobamos que sea equil�tero. Todos sus �ngulos son 60.
				printf("\nEl triangulo es equilatero.");
			else if (x==y || x==z || y==z) //Comprobamos que sea is�sceles. Tiene 2 �ngulos iguales.
				printf("\nEl triangulo es isosceles.");
			else //Si no es ni equil�tero ni is�sceles, es escaleno.
				printf("\nEl triangulo es escaleno.");
		}
		
		getchar();getchar();
		printf("\nIntentarlo de nuevo? (s/n)");
		scanf("%c", &opcion);
	}
	return 0;
}
