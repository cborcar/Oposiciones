/***********************************************************************************/
/************* EJERCICIO FUNCIONES CON N� VARIABLE DE ARGUMENTOS 2 C ***************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************/
/*Escribe una funci�n llamada "listar" que imprima por pantalla los par�metros
que se le pasen de tipo entero. El �ltimo par�metro debe valer -1 para indicar
el final de la lista de par�metros. Como m�nimo se recibir� un par�metro que
tambi�n puede valer -1, indicando as� que no se quiere mostrar nada por pantalla.*/

#include <stdio.h>      
#include <stdarg.h>

double Listar (int primero, ...){
       
       va_list parametros;
       int k;
       
       va_start (parametros, primero);
       
       k = primero;
       while (k != -1){
             printf ("%d ", k);
             k = va_arg (parametros, int);
       }
       
       va_end (parametros);
}

int main (){
}

