/***********************************************************************************/
/******************************* EJERCICIO C PUNTEROS ******************************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************
/Crear un array de 50 n�meros aleatorios y despu�s un array de 50 punteros donde cada 
uno apunte a los n�meros anteriores.*/

# include <stdio.h>
# include <stdlib.h>
# include <time.h> //Esta librer�a es para el srand (no siempre hace falta).

int main()
{
    srand (time(NULL)); //Si no hacemos esto, el n�mero aleatorio de rand() ser� siempre el mismo. Con esto toma como referencia la hora y as� cada vez cambia de verdad.
    int i, VectorNumeros[50], *VectorPunteros[50];
    
    for (i=0; i<50;i++){
        VectorNumeros[i] = rand() % 200; //Introducir un n�mero aleatorio entre el 0 y el 200.
        VectorPunteros[i] = &VectorNumeros[i];
    }
 
    for (i=0; i<50;i++){
        printf ("[%d]", *VectorPunteros[i]);
    }
    getchar();
}
