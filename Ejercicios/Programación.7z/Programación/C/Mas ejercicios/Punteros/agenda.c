#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXCADENA 200

enum { Ver=1, Alta, Buscar, Salir };

struct Entrada {
  char * nombre;
  char * direccion;
  char * telefono;
};

struct NodoAgenda {
  struct Entrada datos;
  struct NodoAgenda * sig;
};

typedef struct NodoAgenda * TipoAgenda;


void muestra_entrada(struct NodoAgenda * e)
  // Podr�amos haber pasado e por valor, pero resulta m�s eficiente 
  // /y no mucho m�s
  // inc�modo) hacerlo por referencia: 
  //pasamos as� s�lo 4 bytes en lugar de 12.
{
  printf("Nombre   : %s\n", e->datos.nombre);
  printf("Direcci�n: %s\n", e->datos.direccion);
  printf("Tel�fono : %s\n", e->datos.telefono);
}

void libera_entrada(struct NodoAgenda * e)
{
  int i;

  free(e->datos.nombre);
  free(e->datos.direccion);
  free(e->datos.telefono);
  free(e);
}


TipoAgenda crea_agenda(void)
{
  return NULL;
}

struct NodoAgenda * buscar_entrada_por_nombre(TipoAgenda agenda, char nombre[])
{
  struct NodoAgenda * aux;

  for (aux = agenda; aux != NULL; aux = aux->sig)
    if (strcmp(aux->datos.nombre, nombre) == 0) 
      return aux;

  return NULL;
}


TipoAgenda anyadir_entrada(  TipoAgenda agenda, char nombre[], 
                             char direccion[], char telefono[])
{
  struct NodoAgenda * aux, * e;

  /* Averiguar si ya tenemos una persona con ese nombre */
  if (buscar_entrada_por_nombre(agenda, nombre)  != NULL)
    return agenda;

  /* Si llegamos aqu�, es porque no ten�amos registrada a esa persona. */
  e = malloc(sizeof(struct NodoAgenda));
  e->datos.nombre = malloc((strlen(nombre)+1)*sizeof(char));
  strcpy(e->datos.nombre, nombre);
  e->datos.direccion = malloc((strlen(direccion)+1)*sizeof(char));
  strcpy(e->datos.direccion, direccion);
  e->datos.telefono = malloc((strlen(telefono)+1)*sizeof(char));
  strcpy(e->datos.telefono, telefono);  
  e->sig = agenda;
  agenda = e;
  return agenda;
}

void muestra_agenda(TipoAgenda agenda)
{
  struct NodoAgenda * aux;

  for (aux = agenda; aux != NULL; aux = aux->sig)
    muestra_entrada(aux);
}


void libera_agenda(TipoAgenda agenda)
{
  struct NodoAgenda * aux, *siguiente;

  aux = agenda;
  while (aux != NULL) {
    siguiente = aux->sig;
    libera_entrada(aux);
    aux = siguiente;
  }
}

/************************************************************************
 * Programa principal
 ************************************************************************/

int main(void) 
{
  TipoAgenda miagenda;
  struct NodoAgenda * encontrada;
  int opcion;
  char nombre[MAXCADENA+1];
  char direccion[MAXCADENA+1];
  char telefono[MAXCADENA+1];
  char linea[MAXCADENA+1];

  
  do {
    printf("Men�:\n");
    printf("1) Ver contenido completo de la agenda.\n");
    printf("2) Dar de alta una persona.\n");
    printf("3) Buscar tel�fonos de una persona.\n");
    printf("4) Salir.\n");
    printf("Opci�n: "); 
    gets(linea); sscanf(linea, "%d", &opcion);
    
    switch(opcion) {

      case Ver:
        muestra_agenda(miagenda);
        break;

      case Alta:
        printf("Nombre   : "); gets(nombre);    
        printf("Direcci�n: "); gets(direccion); 
        printf("Tel�fono : "); gets(telefono);  
        miagenda = anyadir_entrada(miagenda, nombre, direccion, telefono);
        break;

      case Buscar:
        printf("Nombre: "); gets(nombre);
        encontrada = buscar_entrada_por_nombre(miagenda, nombre);
        if (encontrada == NULL) 
          printf("No hay nadie llamado %s en la agenda.\n", nombre);
        else 
          muestra_entrada(encontrada);
        break;
    }
  } while (opcion != Salir);

  libera_agenda(miagenda);

  return 0;
}
