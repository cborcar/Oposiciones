/***********************************************************************************/
/******************** PRACTICA 2 - TAD ARBOL BINARIO DE BUSQUEDA *******************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************

/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "TAD_ABB.h"
 
/***********************************************************************************/
/****************************INICIAMOS EL PROGRAMA**********************************/
/***********************************************************************************/
int main()
{
    int Opcion = 0;
    char Letra;
    TipoABB RaizABB;
    TipoListaPalabras Lista = NULL; 
    TipoInfoABB Informacion; 
     
    do 
    {
          system("cls");
          printf ("\n\n");
          printf ("   |======================================|\n");
          printf ("   |-------------EDA PRACTICA 2-----------|\n");
          printf ("   |-------------MENU PRINCIPAL-----------|\n");
          printf ("   |--------Cayetano Borja Carrillo-------|\n");
          printf ("   |======================================|\n\n");
          printf (" Opcion 1: Insertar palabra nueva\n");
          printf (" Opcion 2: Imprimir las palabras de una letra dada\n");  
          printf (" Opcion 3: Imprimir todas las palabras\n");
          printf (" Opcion 4: Suprimir palabra\n");          
          printf (" Opcion 5: Salir del programa\n\n");
          printf(" Elige una opcion: ");
          scanf("%d", &Opcion);
          getchar();
          switch(Opcion) 
          {
                        //CASO 1 : INSERTAR PALABRA NUEVA.
                        case 1:  
                             printf("\n Introduzca la palabra que desea introducir: ");
                             scanf(" %[^\n]",Informacion); 
                             InsertarLista(&Lista, Informacion);  
                             getchar();
                             getchar();
                        break;
                        
                        //CASO 2: IMPRIMIR LAS PALABRAS DE UNA LETRA DADA.
                        case 2:
                             if (Lista != NULL)  
                             {
                                 printf("\n Introduzca la letra: ");
                                 scanf("%c", &Letra); 
                                 BuscarLista (Lista, Letra);
                                 getchar();
                             }
                             else
                             {
                                 printf("\n No hay palabras almacenadas.");
                             }
                             getchar();                    
                        break;
                         
                        //CASO 3: IMPRIMIR TODAS LAS PALABRAS.
                        case 3:
                             if (Lista != NULL)  
                             { 
                                 printf("\n Las palabras son:");
                                 ImprimirTodo (Lista);  
                             }
                             else
                             {
                                 printf("\n No hay palabras almacenadas.");
                             }
                             getchar(); 
                        break;  
                         
                        //CASO 4: ELIMINAR UNA PALABRA.     
                        case 4:
                             if (Lista != NULL)  
                             {     
                                   printf("\n Introduzca la palabra que desea eliminar: ");
                                   scanf(" %[^\n]",Informacion);
                                   EliminarLista(&Lista, Informacion);
                                   getchar();
                             }
                             else
                             {
                                 printf("\n No hay palabras almacenadas.");   
                             }
                             getchar(); 
                        break;
                        
                        case 5:
                            
                        break; 
                         
                        default:
                                printf ("\n Opcion invalida, vuelve a intentarlo.\n");
                                getchar();
                                getchar();
                        break;
          }
    }while (Opcion!=5);
}
