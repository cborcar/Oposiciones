/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "TAD_ABB.h"

/***********************************************************************************/
/**************************FUNCIONES Y PROCEDIMIENTOS*******************************/
/***********************************************************************************/
//CASO 1: INSERTAR NUEVA PALABRA
//Procedimiento que inserta la primera letra a la lista.
void InsertarLista(TipoListaPalabras *Lista, TipoInfoABB Informacion)
{ 
     TipoListaPalabras Nuevo = NULL;
     TipoListaPalabras Ptr = NULL;
     int Encontrado;
     char Letra = Informacion[0];    
     Nuevo = ((TipoListaPalabras)malloc(sizeof(TipoNodoLista)));
     ((*Nuevo).InfoLista).Letra = Letra; 
     (*Nuevo).SigLista = NULL;   
     if (*Lista == NULL)
     {
               *Lista = Nuevo;
               printf ("\n Se ha insertado la letra [%c] en la lista.", ((*(*Lista)).InfoLista).Letra);
               CrearABB(&((*(*Lista)).InfoLista).Arbol);
               InsertarABB(&((*(*Lista)).InfoLista).Arbol, Informacion);
     } 
     else 
     {
         if (Letra < ((*(*Lista)).InfoLista).Letra)
         {
               (*Nuevo).SigLista = *Lista;
               *Lista = Nuevo;
               printf ("\n Se ha insertado la letra [%c] en la lista.", ((*(*Lista)).InfoLista).Letra);
               CrearABB(&((*(*Lista)).InfoLista).Arbol);
               InsertarABB(&((*(*Lista)).InfoLista).Arbol, Informacion);
         }     
         else
         {
             Ptr = *Lista;
             Encontrado = 0;
             while (((*Ptr).SigLista != NULL) && (Encontrado == 0))
             {
                   if (Letra >= ((*(*Ptr).SigLista).InfoLista).Letra) //Letra es mayor o igual que la letra de Ptr->SigLista->InfoLista
                   {
                       Ptr = (*Ptr).SigLista;
                   }
                   else
                   {
                       
                       Encontrado = 1;
                   }
             }
             if (((*Nuevo).InfoLista).Letra != ((*Ptr).InfoLista).Letra)  //Son distintos
             {
                    (*Nuevo).SigLista = (*Ptr).SigLista;
                    (*Ptr).SigLista = Nuevo;
                    printf ("\n Se ha insertado la letra [%c] en la lista.", ((*Nuevo).InfoLista).Letra);
                    CrearABB(&((*Nuevo).InfoLista).Arbol);
                    InsertarABB(&((*Nuevo).InfoLista).Arbol, Informacion);
             }
             else
             {
                 printf ("\n La letra [%c] ya esta en la lista, no se ha insertado.", ((*Ptr).InfoLista).Letra);
                 InsertarABB(&((*Ptr).InfoLista).Arbol, Informacion);
             }
         }
    }
}

//Procedimiento que crea un �rbol.
void CrearABB(TipoABB *RaizABB)
{
  *RaizABB = NULL;
}

//Procedimiento que, una vez introducida la letra en la lista, introduce la palabra en el �rbol.
void InsertarABB(TipoABB *RaizABB, TipoInfoABB Informacion)
{ 
     if(*RaizABB == NULL)
     {
                 TipoABB Nuevo = NULL;
                 Nuevo = ((TipoABB)malloc(sizeof(TipoNodoABB)));
                 strcpy ((*Nuevo).InfoABB, Informacion);
                 (*Nuevo).Izdo = NULL;
                 (*Nuevo).Dcho = NULL;
                 *RaizABB = Nuevo;          
                 printf ("\n Se ha insertado la palabra [%s] en el arbol.", (*(*RaizABB)).InfoABB);        
     }
     else
     {
         if (strcmp(Informacion,(*(*RaizABB)).InfoABB) < 0)
         {
             InsertarABB(&(*(*RaizABB)).Izdo, Informacion);
         }
         else
         {
             if (strcmp(Informacion,(*(*RaizABB)).InfoABB) > 0)
             {
                 InsertarABB(&(*(*RaizABB)).Dcho, Informacion);
             }
             else
             {
                 printf ("\n La palabra [%s] ya esta incluida, no se ha insertado.", Informacion);
             }
         }
     }
}

//CASO 2: IMPRIMIR LAS PALABRAS DE UNA LETRA DADA.
//Procedimiento que busca la letra por la que empieza una palabra en la lista.
void BuscarLista (TipoListaPalabras Lista, char Letra)  
{
     while ((Lista != NULL) && (((*Lista).InfoLista).Letra != Letra))
     {
         Lista = (*Lista).SigLista;
     }
     if (Lista == NULL)
     {
         printf("\n No hay palabras que empiecen por la letra [%c].", Letra);
     }
     else
     {
         printf ("\n Las palabras que empiezan por [%c] son:", ((*Lista).InfoLista).Letra);
         ImprimirABB(((*Lista).InfoLista).Arbol);              
     }
}
 
//Procedimiento que, una vez encontrada la letra en la lista, imprime las palabras de que empiecen por esa letra.
void ImprimirABB(TipoABB RaizABB) //Recorrido Inorden.
{
     if (RaizABB != NULL)
     {
         
         ImprimirABB((*RaizABB).Izdo);
         printf (" [%s]", (*RaizABB).InfoABB);
         ImprimirABB((*RaizABB).Dcho);
     }
}
//CASO 3: IMPRIMIR TODAS LAS PALABRAS.
//Procedimiento que coge todas las letras y lleva a ImprimirABB para imprimir las palabras de esa letra.
void ImprimirTodo(TipoListaPalabras Lista)
{
     while (Lista != NULL)
     {
           ImprimirABB(((*Lista).InfoLista).Arbol);
           Lista = (*Lista).SigLista;
     }    
}

//CASO 4: ELIMINAR UNA PALABRA.
//Procedimiento para buscar la letra inicial de la palabra a eliminar, si no quedan m�s elementos en esa letra elimina la letra lista.
void EliminarLista(TipoListaPalabras *Lista, TipoInfoABB Informacion)
{
     TipoListaPalabras Suprimir = *Lista;
     TipoListaPalabras Anterior = NULL;
     char Letra = Informacion[0];
     int Final = 0;
     int Eliminado = 0;
     int Vacio;
     while ((Letra != ((*Suprimir).InfoLista).Letra) && (Final == 0))
     {
           Anterior = Suprimir;
           if ((*Suprimir).SigLista != NULL)
           {             
                   Suprimir = (*Suprimir).SigLista;
           }
           else
           {
               Final = 1;
           }                  
     }
     if (Final == 1)
     {
               printf("\n Imposible de eliminar ya que [%c] no existe.", Letra);
     }
     else
     {
         EliminarABB(&((*Suprimir).InfoLista).Arbol, Informacion, &Eliminado);
         if (Eliminado == 1)
         {
                   printf("\n La palabra [%s] se ha eliminado con exito.", Informacion);               
         }
         Vacio = ABBVacio (((*Suprimir).InfoLista).Arbol);
         if (Vacio)
         {
                   if (Anterior == NULL)
                   {
                        *Lista = (*Suprimir).SigLista;
                   }
                   else
                   {
                        (*Anterior).SigLista = (*Suprimir).SigLista;
                   }         
         free(Suprimir);
         printf("\n Tambien la letra [%c] de la lista al no haber mas elementos en esta.", Letra);   
         }
     }
} 
 
//Procedimiento que busca la palabra, si la encuentra la elimina.
void EliminarABB(TipoABB *RaizABB, TipoInfoABB Informacion, int *Eliminado)
{
     TipoABB Temp;
     if (*RaizABB == NULL)
     {
             printf("\n Imposible de eliminar ya que [%s] no existe.", Informacion);
     }
     else
     {
         if (strcmp(Informacion, (*(*RaizABB)).InfoABB) < 0)
         {
             EliminarABB(&(*(*RaizABB)).Izdo, Informacion, &*Eliminado);
         }
         else
         {
             if (strcmp(Informacion, (*(*RaizABB)).InfoABB) > 0)
             {
                 EliminarABB(&(*(*RaizABB)).Dcho, Informacion, &*Eliminado);
             }
             else
             {
                 if ((*(*RaizABB)).Izdo == NULL)
                 { //S�lo hijo derecho o ning�n hijo.
                     Temp = *RaizABB;
                     *RaizABB = (*(*RaizABB)).Dcho;
                     free (Temp);
                     *Eliminado = 1;
                 }
                  else
                  {
                      if ((*(*RaizABB)).Dcho == NULL)
                      { //S�lo hijo izquierdo.
                          Temp = *RaizABB;
                          *RaizABB = (*(*RaizABB)).Izdo;      
                          free (Temp);
                          *Eliminado = 1;
                      }
                      else
                      { //Dos hijos.; 
                          BuscarMinimoABB((*(*RaizABB)).Dcho, &Temp); 
                          strcpy((*(*RaizABB)).InfoABB, (*Temp).InfoABB);
                          EliminarABB(&(*(*RaizABB)).Dcho, (*(*RaizABB)).InfoABB, &*Eliminado);          
                      }
                 }
             }
         }
     } 
} 

//Funci�n que comprueba si el arbol est� vac�o.
int ABBVacio (TipoABB RaizABB)
{
    int Vacio;
    Vacio = (RaizABB == NULL); 
    return (Vacio);      
}

//Procedimiento para un nodo que tiene 2 hijos, busca que hijo es el menor.  
void BuscarMinimoABB(TipoABB RaizABB, TipoABB *NodoMinimo)
{
     *NodoMinimo = RaizABB; 
     if (*NodoMinimo != NULL)	   	  
     {
         while ((*(*NodoMinimo)).Izdo != NULL)
         {
               *NodoMinimo = (*(*NodoMinimo)).Izdo;
         }
     }
} 
