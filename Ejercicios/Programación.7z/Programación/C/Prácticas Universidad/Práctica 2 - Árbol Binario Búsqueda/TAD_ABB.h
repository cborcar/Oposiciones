#ifndef TAD_ABB_H_
#define TAD_ABB_H_

/***********************************************************************************/
/***********************DECLARAMOS LOS TIPOS DE DATOS*******************************/
/***********************************************************************************/

//DEL �RBOL BINARIO DE B�SQUEDA
typedef char TipoInfoABB[20];
 
typedef struct NodoABB
{
        TipoInfoABB InfoABB;  
        struct NodoABB *Izdo,*Dcho;
}TipoNodoABB;
  
typedef TipoNodoABB *TipoABB;

//DE LA LISTA  
typedef struct    
{  
        char Letra; 
        TipoABB Arbol;  
}TipoInfoLista;
 
typedef struct NodoLista
{
        TipoInfoLista InfoLista;
        struct NodoLista *SigLista;
}TipoNodoLista;

typedef TipoNodoLista *TipoListaPalabras; 

/***********************************************************************************/
/*******************DECLARAMOS LAS FUNCIONES Y/O PROCEDIMIENTOS*********************/
/***********************************************************************************/
 
//DEL �RBOL BINARIO DE B�SQUEDA 
void CrearABB(TipoABB *RaizABB);
void InsertarABB(TipoABB *RaizABB, TipoInfoABB Informacion);
void ImprimirABB(TipoABB RaizABB);  
void EliminarABB(TipoABB *RaizABB, TipoInfoABB Informacion, int *Eliminado);
void BuscarMinimoABB(TipoABB RaizABB, TipoABB *NodoMinimo);
int ABBVacio (TipoABB RaizABB);

//DE LA LISTA  
void InsertarLista(TipoListaPalabras *Lista, TipoInfoABB Informacion);
void BuscarLista (TipoListaPalabras Lista, char Letra); 
void ImprimirTodo(TipoListaPalabras Lista);
void EliminarLista(TipoListaPalabras *Lista, TipoInfoABB Informacion);

#endif
