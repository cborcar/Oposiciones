/***********************************************************************************/
/******************************** PRACTICA 4 - GRAFOS ******************************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************

/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/
#include <stdio.h>
#include <stdlib.h> 
#include "TAD_Grafo.h" 

/***********************************************************************************/
/****************************INICIAMOS EL PROGRAMA**********************************/
/***********************************************************************************/
int main()
{
    int Opcion = 0;
    TipoGrafo Grafo = NULL;
    TipoListaVertices ArbolExtension = NULL;
    int Creado = 0;
    do
    {
          system("cls");
          printf ("\n\n");
          printf ("   |======================================|\n");
          printf ("   |-------------EDA PRACTICA 4-----------|\n");
          printf ("   |-------------MENU PRINCIPAL-----------|\n");
          printf ("   |--------Cayetano Borja Carrillo-------|\n");
          printf ("   |======================================|\n\n");
          printf (" Opcion 1: Crear grafo\n");
          printf (" Opcion 2: Insertar aristas al grafo\n");
          printf (" Opcion 3: Ver la lista de adyacencias\n");
          printf (" Opcion 4: Encontrar camino minimo de todos los vertices (Floyd)\n");
          printf (" Opcion 5: Encontrar arbol de extension minimal (Prim)\n");
          printf (" Opcion 6: Ver el arbol de extension minimal\n");               
          printf (" Opcion 7: Salir del programa\n\n");
          printf(" Elige una opcion: ");
          scanf("%d", &Opcion);
          getchar(); 
          switch(Opcion) 
          {
                        //CASO 1 : CREAR GRAFO.
                        case 1:
                             if (!Creado)
                             {
                                         CrearGrafo(&Grafo);
                                         if (Grafo == NULL)
                                         {
                                             Creado = 0;            
                                         }
                                         else
                                         {
                                             Creado = 1;
                                             printf("\n El Grafo ha sido creado con exito.");
                                             getchar();
                                             getchar(); 
                                         }
                             }
                             else
                             {
                                 printf("\n No se puede crear el grafo porque ya esta creado.");
                                 getchar(); 
                             }
                        break;
                         
                        //CASO 2: INSERTAR ARISTAS AL GRAFO.
                        case 2:
                             if (Creado)
                             {
                                 PedirDatos(&Grafo);       
                             }
                             else
                             {
                                 printf("\n Imposible, el grafo aun no se ha creado.");
                             }
                             getchar();               
                        break;
                        
                        //CASO 3: VER LA LISTA DE ADYACENCIAS.
                        case 3:
                             if (Creado)
                             {
                                 VerListaAdyacencias((*Grafo).Vertices);       
                             }
                             else
                             {
                                 printf("\n Imposible, el grafo aun no se ha creado.");
                             }
                             getchar();                        
                        break;
                        
                        //CASO 4: ALGORITMO FLOYD.
                        case 4:
                             if (Creado)
                             {
                                 ComprobarGrafo(Grafo);       
                             }
                             else
                             {
                                 printf("\n Imposible, el grafo aun no se ha creado.");
                                 getchar();
                             }                        
                        break;  
                        
                        //CASO 5: ALGORITMO PRIM.
                        case 5:
                             if (Creado)
                             {
                                 ComprobarGrafo2(Grafo, &ArbolExtension);       
                             }
                             else
                             {
                                 printf("\n Imposible, el grafo aun no se ha creado.");
                             }
                             getchar();                        
                        break;
                        
                        //CASO 6: VER EL �RBOL DE EXTENSI�N MINIMAL.
                        case 6:
                             if (Creado)
                             {
                                 if (ArbolExtension != NULL)
                                 {
                                       VerListaAdyacencias(ArbolExtension);
                                 }
                                 else
                                 {
                                        printf("\n Imposible, el arbol de extension minimal aun no se ha creado."); 
                                 }       
                             }
                             else
                             {
                                 printf("\n Imposible, el grafo aun no se ha creado.");
                             }
                             getchar();                        
                        break;   
                                                                     
                        case 7:
                            
                        break; 
                         
                        default:
                                printf ("\n Opcion invalida, vuelve a intentarlo.\n");
                                getchar();
                                getchar();
                        break;
          }
    }while (Opcion!=7);
}
