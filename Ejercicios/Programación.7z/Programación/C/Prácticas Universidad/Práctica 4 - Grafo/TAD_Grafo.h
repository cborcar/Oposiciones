#ifndef TAD_GRAFO_H_
#define TAD_GRAFO_H_
 
/***********************************************************************************/
/***********************DECLARAMOS LOS TIPOS DE DATOS*******************************/
/***********************************************************************************/

//Estructura para guardar las aristas ordenadas por peso en Prim.
typedef struct NodoAristas
{
        int VerticeOrigen;
        int VerticeDestino;
        int PesoArista;
        struct NodoAristas *SigArista;    
}TipoNodoAristas;

typedef TipoNodoAristas *TipoListaAristas;

//Estructura del grafo completo.
typedef struct NodoAdyacente
{
        int VerticeAdyacente;
        int PesoArista;
        struct NodoAdyacente *SigAdyacente;    
}TipoNodoAdyacentes;

typedef TipoNodoAdyacentes *TipoListaAdyacentes;

typedef struct NodoVertice
{
        int Vertice;
        TipoListaAdyacentes Adyacentes;
        struct NodoVertice *SigVertice;    
}TipoNodoVertices;

typedef TipoNodoVertices *TipoListaVertices;

typedef struct NodoGrafo
{
        int Ponderado;
        int Dirigido;
        TipoListaVertices Vertices;
}TipoNodoGrafo;

typedef TipoNodoGrafo *TipoGrafo;

/***********************************************************************************/
/*******************DECLARAMOS LAS FUNCIONES Y/O PROCEDIMIENTOS*********************/
/***********************************************************************************/
//CASO 1 : CREAR GRAFO.
void CrearGrafo(TipoGrafo *Grafo);
void PedirVertices(TipoListaVertices *ListaVertices);
void InsertarVertices(TipoListaVertices *ListaVertices, int NumVertices);

//CASO 2: INSERTAR ARISTAS AL GRAFO.
void PedirDatos(TipoGrafo *Grafo);
int ContarVertices(TipoListaVertices ListaVertices);
void InsertarArista(TipoListaVertices *ListaVertices, int PesoArista, int VerticeOrigen, int VerticeDestino, int *Insertado);
void InsertarAdyacente (TipoListaAdyacentes *ListaAdyacentes, int PesoArista, int VerticeDestino, int *Insertado);

//CASO 3: VER LA LISTA DE ADYACENCIAS.
void VerListaAdyacencias(TipoListaVertices ListaVertices);
void VerAdyacentes(TipoListaAdyacentes ListaAdyacentes);

//CASO 4: ALGORITMO FLOYD.
void ComprobarGrafo(TipoGrafo Grafo);
void Floyd(TipoGrafo Grafo, int NumVertices);

//CASO 5: ALGORITMO PRIM.
void ComprobarGrafo2(TipoGrafo Grafo, TipoListaVertices *ArbolExtension);
void Prim(TipoGrafo Grafo, TipoListaVertices *ArbolExtension, int NumVertices);
void InsertarListaAristas (TipoListaAristas *ListaAristas, int VerticeOrigen, int VerticeDestino, int PesoArista);
void InsertarColaReservadas (TipoListaAristas *ColaReservadas, int VerticeOrigen, int VerticeDestino, int PesoArista);

#endif
