/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "TAD_Grafo.h" 

/***********************************************************************************/
/**************************FUNCIONES Y PROCEDIMIENTOS*******************************/
/***********************************************************************************/
//CASO 1: CREAR GRAFO.
//Procedimiento que crea el grafo del tipo elegido.
void CrearGrafo(TipoGrafo *Grafo)
{
    int Opcion = 0;
    do
    {
          system("cls");
          printf ("\n\n");
          printf ("   |======================================|\n");
          printf ("   |-------------EDA PRACTICA 4-----------|\n");
          printf ("   |-------------MENU PRINCIPAL-----------|\n");
          printf ("   |--------Cayetano Borja Carrillo-------|\n");
          printf ("   |======================================|\n\n");
          printf (" Opcion 1: Crear Grafo dirigido y ponderado\n");
          printf (" Opcion 2: Crear Grafo dirigido y no ponderado\n");
          printf (" Opcion 3: Crear Grafo no dirigido y ponderado\n");  
          printf (" Opcion 4: Crear Grafo no dirigido y no ponderado\n");                         
          printf (" Opcion 5: Cancelar\n\n");
          printf(" Elige una opcion: ");
          scanf("%d", &Opcion);
          getchar(); 
          switch(Opcion) 
          {
                        //CASO 1 : GRAFO DIRIGIDO Y PONDERADO.
                        case 1:
                             *Grafo = (TipoGrafo)malloc(sizeof(TipoNodoGrafo));
                             (*(*Grafo)).Dirigido = 1;
                             (*(*Grafo)).Ponderado = 1;
                             (*(*Grafo)).Vertices = NULL;
                             PedirVertices(&(*(*Grafo)).Vertices);
                             Opcion = 5;
                        break;
                         
                        //CASO 2: GRAFO DIRIGIDO Y NO PONDERADO.
                        case 2:
                             *Grafo = (TipoGrafo)malloc(sizeof(TipoNodoGrafo));
                             (*(*Grafo)).Dirigido = 1;
                             (*(*Grafo)).Ponderado = 0;
                             (*(*Grafo)).Vertices = NULL;
                             PedirVertices(&(*(*Grafo)).Vertices);
                             Opcion = 5;           
                        break;
                        
                        //CASO 3: GRAFO NO DIRIGIDO Y PONDERADO.
                        case 3:
                             *Grafo = (TipoGrafo)malloc(sizeof(TipoNodoGrafo));
                             (*(*Grafo)).Dirigido = 0;
                             (*(*Grafo)).Ponderado = 1;
                             (*(*Grafo)).Vertices = NULL;
                             PedirVertices(&(*(*Grafo)).Vertices);
                             Opcion = 5;                      
                        break;
                        
                        //CASO 4: GRAFO NO DIRIGIDO Y NO PONDERADO.
                        case 4:
                             *Grafo = (TipoGrafo)malloc(sizeof(TipoNodoGrafo));
                             (*(*Grafo)).Dirigido = 0;
                             (*(*Grafo)).Ponderado = 0;
                             (*(*Grafo)).Vertices = NULL;
                             PedirVertices(&(*(*Grafo)).Vertices);
                             Opcion = 5;                              
                        break;
                        
                        case 5:
                            
                        break;  
                         
                        default:
                                printf ("\n Opcion invalida, vuelve a intentarlo.\n");
                                getchar();
                        break;
          }
    }while (Opcion!=5);
}

//Procedimiento pide cu�ntos v�rtices se insertar�n al grafo.
void PedirVertices(TipoListaVertices *ListaVertices)
{
     int NumVertices;   
     printf("\n Indique cuantos vertices tendra el grafo (Minimo 2): ");
     scanf("%d",&NumVertices);
     if (NumVertices < 2)
     {
         printf("\n Tiene que tener 2 o mas vertices, intentelo otra vez.\n");
         PedirVertices(&*ListaVertices);                         
     }
     else
     {
         InsertarVertices(*&ListaVertices, NumVertices);
     }
}

//Procedimiento que insertar� los v�rtices dichos anteriormente al grafo.
void InsertarVertices(TipoListaVertices *ListaVertices, int NumVertices)
{
     TipoListaVertices Ptr;
     TipoListaVertices Nuevo;
     int i; 
     for (i=0;i<NumVertices; i++)
     {
         Nuevo = NULL;
         if (*ListaVertices == NULL)
         {
             *ListaVertices = (TipoListaVertices)malloc(sizeof(TipoNodoVertices));
             (*(*ListaVertices)).Vertice  = i;
             (*(*ListaVertices)).SigVertice = NULL;
             (*(*ListaVertices)).Adyacentes = NULL;
             Ptr = *ListaVertices;                         
         }
         else
         {
             Nuevo = (TipoListaVertices)malloc(sizeof(TipoNodoVertices));
             (*Nuevo).Vertice  = i;
             (*Nuevo).SigVertice = NULL;
             (*Nuevo).Adyacentes = NULL;
             (*Ptr).SigVertice = Nuevo;
             Ptr = (*Ptr).SigVertice;
         }
     }
}      

//CASO 2: INSERTAR ARISTAS AL GRAFO.
//Procedimiento que pide los datos necesarios.
void PedirDatos(TipoGrafo *Grafo)
{
     int NumVertices;
     int VerticeOrigen = -1;
     int VerticeDestino = -2;
     int PesoArista = 0;
     int Insertado = 0;
     char Eleccion;
     NumVertices = ContarVertices((*(*Grafo)).Vertices);   
     while ((VerticeOrigen < 0) || (VerticeOrigen >= NumVertices))
     {
           printf("\n Indique el vertice de origen: ");
           scanf("%d",&VerticeOrigen);
           if ((VerticeOrigen < 0) || (VerticeOrigen >= NumVertices))
           {
                 printf("\n Hay %d vertices, el vertice ha de estar entre 0 y %d, intentelo otra vez.\n", NumVertices, NumVertices - 1);                    
                 getchar();
           }
     }
     while ((VerticeDestino < 0) || (VerticeDestino >= NumVertices))
     {
           printf("\n Indique el vertice de destino: ");
           scanf("%d",&VerticeDestino);
           if ((VerticeDestino < 0) || (VerticeDestino >= NumVertices))
           {
                 printf("\n Hay %d vertices, el vertice ha de estar entre 0 y %d, intentelo otra vez.\n", NumVertices, NumVertices - 1);                    
                 getchar();
           }
     }
     if (VerticeOrigen == VerticeDestino)
     {
           printf("\n No puede ser el mismo vertice origen y destino, intentelo otra vez.");
           getchar();
           getchar();
           PedirDatos(&*Grafo);
     }
     else
     {
           if ((*(*Grafo)).Ponderado == 1)
           {
                 while (PesoArista <= 0)
                 {
                        printf("\n Indique el peso de la arista: ");
                        scanf("%d",&PesoArista);
                        if (PesoArista <= 0)
                        {
                                  printf("\n El peso de la arista tiene que ser mayor que 0, intentelo otra vez.\n");
                        }
                 }             
           }
           else
           {
                 PesoArista = 0;
           }
           if ((*(*Grafo)).Dirigido == 1)
           {
                 InsertarArista(&(*(*Grafo)).Vertices, PesoArista, VerticeOrigen, VerticeDestino, &Insertado);
           }
           else
           {
                 InsertarArista(&(*(*Grafo)).Vertices, PesoArista, VerticeOrigen, VerticeDestino, &Insertado);
                 InsertarArista(&(*(*Grafo)).Vertices, PesoArista, VerticeDestino, VerticeOrigen, &Insertado);
           }
           if (Insertado == 1)
           {
                 printf ("\n La arista se ha insertado con exito.");
           }
           else
           {
                 printf ("\n Arista repetida, no se ha insertado.");
           }
           printf ("\n\n Desea insertar mas aristas? (Pulse s si es que si): ");
           scanf(" %c", &Eleccion);
           if (Eleccion == 's')
           {
                PedirDatos(&*Grafo);
           }
     }   
}

//Funcion que cuenta los vertices que hay.
int ContarVertices(TipoListaVertices ListaVertices)
{
     int NumVertices = 0;
     while (ListaVertices != NULL)
     {
           NumVertices = NumVertices + 1;
           ListaVertices = (*ListaVertices).SigVertice;
           
     }
     return (NumVertices);  
}

//Procedimiento que busca el vertice origen en el grafo para insertar la arista ah�.
void InsertarArista(TipoListaVertices *ListaVertices, int PesoArista, int VerticeOrigen, int VerticeDestino, int *Insertado)
{
     TipoListaVertices Ptr;
     Ptr = *ListaVertices;
     int Encontrado = 0;
     while (Encontrado == 0)
     {
           if ((*Ptr).Vertice == VerticeOrigen)
           {                              
                InsertarAdyacente (&(*Ptr).Adyacentes, PesoArista, VerticeDestino, &*Insertado);              
                Encontrado = 1;
                
           }
           else
           {
               Ptr = (*Ptr).SigVertice;
           }           
     }       
}

//Procedimiento que inserta el peso y el vertice destino en el vertice origen calculado anteriormente.
void InsertarAdyacente (TipoListaAdyacentes *ListaAdyacentes, int PesoArista, int VerticeDestino, int *Insertado)
{
     TipoListaAdyacentes Nuevo, Ptr;
     int Encontrado;
     Nuevo = ((TipoListaAdyacentes)malloc(sizeof(TipoNodoAdyacentes))); 
     (*Nuevo).VerticeAdyacente = VerticeDestino;
     (*Nuevo).PesoArista = PesoArista;
     (*Nuevo).SigAdyacente = NULL;
     if (*ListaAdyacentes == NULL)
     {
               *ListaAdyacentes = Nuevo;
               *Insertado = 1;
     }
     else
     {
         if (VerticeDestino < (*(*ListaAdyacentes)).VerticeAdyacente)
         {
                      (*Nuevo).SigAdyacente = *ListaAdyacentes;
                      *ListaAdyacentes = Nuevo;
                      *Insertado = 1;
                                   
         }
         else
         {
             Ptr = *ListaAdyacentes;
             Encontrado = 0;
             while (((*Ptr).SigAdyacente != NULL) && (!Encontrado))
             {
                   if (VerticeDestino >= (*(*Ptr).SigAdyacente).VerticeAdyacente)
                   {
                                Ptr = (*Ptr).SigAdyacente;
                   }
                   else
                   {
                       Encontrado = 1;
                   }    
             } 
             if ((*Nuevo).VerticeAdyacente != (*Ptr).VerticeAdyacente)
             {
                   (*Nuevo).SigAdyacente = (*Ptr).SigAdyacente;
                   (*Ptr).SigAdyacente = Nuevo;
                   *Insertado = 1; 
             }
             else
             {
                   *Insertado = 0;
             }    
         }
     }
}

//CASO 3: VER LA LISTA DE ADYACENCIAS.
//Procedimiento que muestra la lista de vertices y sus adyacentes.
void VerListaAdyacencias(TipoListaVertices ListaVertices)
{
     printf ("\n |=================================================|\n");
     printf (" |[VERTICE] -----> [VERTICE ADYACENTE, PESO ARISTA]|\n");
     printf (" |=================================================|\n");
     
     while (ListaVertices != NULL)
     {
           printf("\n   V[%d] ----", (*ListaVertices).Vertice);
           if ((*ListaVertices).Adyacentes == NULL)
           {
                  printf("-> Ningun vertice adyacente.");                         
           }
           else
           {
                  VerAdyacentes((*ListaVertices).Adyacentes); 
           }
           ListaVertices = (*ListaVertices).SigVertice;
           
     }
     printf ("\n");
}

//Procedimiento que muestra los adyacentes de un vertice dado.
void VerAdyacentes(TipoListaAdyacentes ListaAdyacentes)
{
     while (ListaAdyacentes != NULL)
     {
           printf("-> V[%d], P[%d] ", (*ListaAdyacentes).VerticeAdyacente, (*ListaAdyacentes).PesoArista);
           ListaAdyacentes = (*ListaAdyacentes).SigAdyacente;
           
     }
}

//CASO 4: ALGORITMO FLOYD.
//Procedimiento que comprueba si se puede aplicar Floyd sobre el grafo.
void ComprobarGrafo(TipoGrafo Grafo)
{
     int NumVertices;    
     if (((*Grafo).Dirigido == 1) && ((*Grafo).Ponderado == 1))
     {
           NumVertices = ContarVertices((*Grafo).Vertices);
           Floyd(Grafo, NumVertices);                  
     }
     else
     {
          printf ("\n Para realizar el algoritmo Floyd el grafo ha de ser dirigido y ponderado.");
          getchar();      
     }   
}

//Procedimiento que ejecuta el algoritmo Floyd
void Floyd(TipoGrafo Grafo, int NumVertices)
{
    int TablaDistancias [NumVertices][NumVertices];
    int TablaVerticeAnterior [NumVertices][NumVertices];
    int i;
    int j;
    int k;
    TipoListaVertices PtrVertices;
    PtrVertices = (*Grafo).Vertices;
    TipoListaAdyacentes PtrAdyacentes;
  
    // Construimos las tablas.
	for (i = 0; i < NumVertices; i++)
    {
		for (j = 0; j < NumVertices; j++)
        {
			if (i == j)
            {
				TablaDistancias[i][j] = 0;
				TablaVerticeAnterior[i][j] = i;
			}
            else
            {
				TablaDistancias[i][j] = -1;
				TablaVerticeAnterior[i][j] = -1;
			}
		}
	}
	for (i = 0; i < NumVertices; i++)
    {
        PtrAdyacentes = (*PtrVertices).Adyacentes;
        while (PtrAdyacentes != NULL)
        {
              TablaDistancias[i][(*PtrAdyacentes).VerticeAdyacente] = (*PtrAdyacentes).PesoArista;
              TablaVerticeAnterior[i][(*PtrAdyacentes).VerticeAdyacente] = i;
              PtrAdyacentes = (*PtrAdyacentes).SigAdyacente;
              
        }
        PtrVertices = (*PtrVertices).SigVertice;
    }
    
    //Y las actualizamos donde sea necesario.
    for (k = 0; k < NumVertices; k++)
    {
		for (i = 0; i < NumVertices; i++)
        {
			for (j = 0; j < NumVertices; j++)
            {
				if ((TablaDistancias[i][k] != -1) && (TablaDistancias[k][j] != -1))
                {
					if ((TablaDistancias[i][j] == -1) || ((TablaDistancias[i][k] + TablaDistancias[k][j]) < TablaDistancias[i][j]))
                    {
						TablaDistancias[i][j] = TablaDistancias[i][k] + TablaDistancias[k][j];
						TablaVerticeAnterior[i][j] = k;
					}
				}
			}
		}
    }
       
    //Ya ha acabado el algoritmo Floyd, imprimo por pantalla los resultados.
    for (i = 0; i < NumVertices; i++)
    {
        printf ("\n Del vertice [%d] al:",i);
        for (j = 0; j < NumVertices; j++)
        {
            if (i != j)
            {
                  if (TablaDistancias[i][j] == -1)
                  {
                      printf("\n        [%d] no existe ningun camino posible.",j);                     
                  }
                  else
                  {
                      printf("\n        [%d] hay una distancia de [%d] siendo el vertice anterior [%d].",j, TablaDistancias[i][j], TablaVerticeAnterior[i][j]);
                  }
            }
        }
        getchar();       
    }      
}

//CASO 5: ALGORITMO PRIM.
//Procedimiento que comprueba si se puede aplicar Prim sobre el grafo.
void ComprobarGrafo2(TipoGrafo Grafo, TipoListaVertices *ArbolExtension)
{
     int Conexo = 1;
     int NumVertices;
     TipoListaVertices ListaVertices;
     ListaVertices = (*Grafo).Vertices;
         
     if (((*Grafo).Dirigido == 0) && ((*Grafo).Ponderado == 1))
     {
           //Comprobamos si el grafo es conexo.
           while ((ListaVertices != NULL) && (Conexo != 0))
           {
                 if ((*ListaVertices).Adyacentes == NULL)
                 {                                                
                           Conexo = 0;
                 }
                 ListaVertices = (*ListaVertices).SigVertice;                                     
           }
           if (Conexo == 1)
           {
                 NumVertices = ContarVertices((*Grafo).Vertices);               
                 Prim(Grafo, &*ArbolExtension, NumVertices);
           }
           else
           {
                 printf ("\n Para realizar el algoritmo Prim el grafo ha de ser conexo.");
           }                  
     }
     else
     {
          printf ("\n Para realizar el algoritmo Prim el grafo ha de ser no dirigido y ponderado.");      
     }   
}


//Procedimiento que ejecuta el algoritmo Prim.
void Prim(TipoGrafo Grafo, TipoListaVertices *ArbolExtension, int NumVertices)
{
     TipoListaAristas ListaAristas = NULL;
     TipoListaAristas ColaReservadas = NULL;
     TipoListaAristas PtrAristaATratar = NULL;
     TipoListaVertices PtrVertices;
     TipoListaAdyacentes PtrAdyacentes;
     PtrVertices = (*Grafo).Vertices;  
     int i;
     int Insertado;
     int Parar;
     int ComponentesConexas[NumVertices -1];
    
     //Insertamos en ListaAristas las aristas del grafo ordenados por peso de menor a mayor.   
     while (PtrVertices != NULL)
     {
           PtrAdyacentes = (*PtrVertices).Adyacentes;
           while (PtrAdyacentes != NULL)
           {
                 InsertarListaAristas (&ListaAristas, (*PtrVertices).Vertice, (*PtrAdyacentes).VerticeAdyacente, (*PtrAdyacentes).PesoArista);
                 PtrAdyacentes = (*PtrAdyacentes).SigAdyacente;   
           }
           PtrVertices = (*PtrVertices).SigVertice;    
     }
        
     //Inicializamos componentes conexas con un vertice G
     for (i=0;i<NumVertices; i++)
     {
         ComponentesConexas[i] = 0;        
     }
     ComponentesConexas[0] = 1;
     
     //Inserto los vertices en el �rbol del extensi�n.
     InsertarVertices(&*ArbolExtension, NumVertices);
     
     while ((ListaAristas != NULL) && (NumVertices > 1))
     {
           Parar = 0;
           //Elegir la arista de menor peso aun no considerada o reservada.
           if (ColaReservadas != NULL)
           {
                   PtrAristaATratar = (*ColaReservadas).SigArista;
                   (*ColaReservadas).SigArista = (*PtrAristaATratar).SigArista;
                   if ((*ColaReservadas).SigArista == PtrAristaATratar)
                   {
                          ColaReservadas = NULL;                                                                          
                   }         
           }
           else
           {
               PtrAristaATratar = ListaAristas;
               ListaAristas = (*ListaAristas).SigArista;
           }
           
           while ((Parar == 0) && (PtrAristaATratar != NULL))
           {
                 printf("\n Trataremos la arista [%d,%d] con peso [%d]", (*PtrAristaATratar).VerticeOrigen, (*PtrAristaATratar).VerticeDestino, (*PtrAristaATratar).PesoArista);
                 
                 //Si uno de los vertices pertenece a componente conexa y el otro no.
                 if ((ComponentesConexas[(*PtrAristaATratar).VerticeOrigen] == 1) && (ComponentesConexas[(*PtrAristaATratar).VerticeDestino] == 0) || (ComponentesConexas[(*PtrAristaATratar).VerticeOrigen] == 0) && (ComponentesConexas[(*PtrAristaATratar).VerticeDestino] == 1))
                 {  
                     //A�adir a ComponentesConexas el vertice que no pertenecia.                                              
                     if ((ComponentesConexas[(*PtrAristaATratar).VerticeOrigen] == 1) && (ComponentesConexas[(*PtrAristaATratar).VerticeDestino] == 0))
                     {
                            ComponentesConexas[(*PtrAristaATratar).VerticeDestino] = 1;                                                   
                     }
                     else
                     {
                            ComponentesConexas[(*PtrAristaATratar).VerticeOrigen] = 1;
                     }
                     InsertarArista(&*ArbolExtension, (*PtrAristaATratar).PesoArista, (*PtrAristaATratar).VerticeOrigen,(*PtrAristaATratar).VerticeDestino, &Insertado);
                     InsertarArista(&*ArbolExtension, (*PtrAristaATratar).PesoArista, (*PtrAristaATratar).VerticeDestino,(*PtrAristaATratar).VerticeOrigen, &Insertado);
                     Parar = 1; 
                     free (PtrAristaATratar);
                     NumVertices = NumVertices - 1;
                     printf(" (Arista Insertada)");
                     getchar();                                                  
                 }
                 else
                 {
                     if ((ComponentesConexas[(*PtrAristaATratar).VerticeOrigen] == 0) && (ComponentesConexas[(*PtrAristaATratar).VerticeDestino] == 0))
                     {
                               InsertarColaReservadas (&ColaReservadas, (*PtrAristaATratar).VerticeOrigen, (*PtrAristaATratar).VerticeDestino, (*PtrAristaATratar).PesoArista);
                               free (PtrAristaATratar);
                               PtrAristaATratar = ListaAristas;
                               ListaAristas = (*ListaAristas).SigArista;
                               printf(" (Arista Reservada)");
                               getchar();                                                                                                                              
                     }
                     else
                     {
                               free (PtrAristaATratar);
                               PtrAristaATratar = ListaAristas;
                               ListaAristas = (*ListaAristas).SigArista;
                               printf(" (Arista Rechazada)");
                               getchar();                        
                     }
                 }     
           }  
     }
     printf("\n El Arbol de Extension Minimal ha sido creado con exito.");
}

//Procedimiento que inserta las aristas del grafo en ListaAristas ordenados por peso de menor a mayor.
void InsertarListaAristas (TipoListaAristas *ListaAristas, int VerticeOrigen, int VerticeDestino, int PesoArista)
{
     TipoListaAristas Ptr;
     TipoListaAristas Nuevo = NULL;
     Ptr = *ListaAristas;
     int Encontrado = 0;
     int Repetido = 0;     
     Nuevo = ((TipoListaAristas)malloc(sizeof(TipoNodoAristas)));
     (*Nuevo).VerticeOrigen = VerticeOrigen;
     (*Nuevo).VerticeDestino = VerticeDestino;
     (*Nuevo).PesoArista = PesoArista;
     (*Nuevo).SigArista = NULL;               
     //Primero vemos si existe algun elemento en ListaAristas que VerticeOrigen = VDestino y VerticeDestino = VerticeOrigen para no insertarlo.
     while ((Ptr != NULL) && (Repetido == 0))
     {
           if (((*Ptr).VerticeOrigen == (*Nuevo).VerticeDestino) && ((*Ptr).VerticeDestino == (*Nuevo).VerticeOrigen))
           {
                  Repetido = 1;                                                                         
           }
           else
           {
                  Ptr = (*Ptr).SigArista; 
           }         
     }
     if (Repetido == 0)
     {
                  if (*ListaAristas == NULL)
                  {
                           *ListaAristas = Nuevo;
                  }
                  else
                  {
                      if ((*Nuevo).PesoArista <= (*(*ListaAristas)).PesoArista)
                      {
                            (*Nuevo).SigArista = *ListaAristas;
                            *ListaAristas = Nuevo;
                      }
                      else
                      {
                          Ptr = *ListaAristas;
                          while (((*Ptr).SigArista != NULL) && (Encontrado == 0))
                          {
                                if ((*Nuevo).PesoArista > (*(*Ptr).SigArista).PesoArista)
                                {
                                    Ptr = (*Ptr).SigArista;
                                }
                                else
                                {
                                    Encontrado = 1;
                                }    
                          }
                          (*Nuevo).SigArista = (*Ptr).SigArista;
                          (*Ptr).SigArista = Nuevo;     
                      }
                  }
     }
}

//Procedimiento que inserta en una cola los elementos reservados.
void InsertarColaReservadas (TipoListaAristas *ColaReservadas, int VerticeOrigen, int VerticeDestino, int PesoArista)
{
     TipoListaAristas Nuevo;
     Nuevo = ((TipoListaAristas)malloc(sizeof(TipoNodoAristas)));
     (*Nuevo).VerticeOrigen = VerticeOrigen;
     (*Nuevo).VerticeDestino = VerticeDestino;
     (*Nuevo).PesoArista = PesoArista;
     (*Nuevo).SigArista = NULL;
     if (*ColaReservadas == NULL)
     {
               *ColaReservadas = Nuevo;
               (*Nuevo).SigArista = Nuevo;
     }
     else
     {
         (*Nuevo).SigArista = (*(*ColaReservadas)).SigArista;
         (*(*ColaReservadas)).SigArista = Nuevo;
         *ColaReservadas = Nuevo;
     }                      
}
