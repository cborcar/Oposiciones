/***********************************************************************************/
/************************** PRACTICA 3 - COLA DE PRIORIDAD *************************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************

/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/
#include <stdio.h>
#include <stdlib.h> 
#include "TAD_ColaP.h" 
 
/***********************************************************************************/
/****************************INICIAMOS EL PROGRAMA**********************************/
/***********************************************************************************/
int main()
{
    int Opcion = 0;
    TipoLista Lista = NULL;
    TInfoLista Nombre;
    TInfoLista Apellidos;
    do
    {
          system("cls");
          printf ("\n\n");
          printf ("   |======================================|\n");
          printf ("   |-------------EDA PRACTICA 3-----------|\n");
          printf ("   |-------------MENU PRINCIPAL-----------|\n");
          printf ("   |--------Cayetano Borja Carrillo-------|\n");
          printf ("   |======================================|\n\n");
          printf (" Opcion 1: Insertar un alumno\n");
          printf (" Opcion 2: Insertar notas a un alumno\n");
          printf (" Opcion 3: Imprimir todos los alumnos con su nota maxima\n");           
          printf (" Opcion 4: Eliminar la nota mas alta de un alumno\n");
          printf (" Opcion 5: Eliminar un alumno y sus notas.\n"); 
          printf (" Opcion 6: Eliminar todos los alumnos y sus notas\n");          
          printf (" Opcion 7: Salir del programa\n\n");
          printf(" Elige una opcion: ");
          scanf("%d", &Opcion);
          getchar(); 
          switch(Opcion) 
          {
                        //CASO 1 : INSERTAR UN ALUMNO EN LA LISTA.
                        case 1:
                             printf("\n Introduzca el nombre del alumno: ");
                             scanf(" %[^\n]",Nombre); 
                             printf("\n Introduzca los apellidos del alumno: "); 
                             scanf(" %[^\n]",Apellidos);
                             InsertarLista(&Lista, Nombre, Apellidos); 
                             getchar();
                             getchar();  
                        break;
                         
                        //CASO 2: INSERTAR NOTAS A UN ALUMNO.
                        case 2:
                             if (Lista != NULL)  
                             {
                                       printf("\n Introduzca el nombre del alumno: ");
                                       scanf(" %[^\n]",Nombre); 
                                       printf("\n Introduzca los apellidos del alumno: "); 
                                       scanf(" %[^\n]",Apellidos);
                                       InsertarNotas (Lista, Nombre, Apellidos);  
                             }
                             else
                             {
                                 printf("\n No hay alumnos almacenados.");
                             }
                             getchar();                  
                        break;
                        
                        //CASO 3: IMPRIMIR TODOS LOS ALUMNOS CON LA NOTA MAXIMA DE CADA UNO
                        case 3:
                             if (Lista != NULL)  
                             {
                                       ImprimirTodo(Lista);  
                             }
                             else
                             {
                                 printf("\n No hay alumnos almacenados.");
                             }
                             getchar();                             
                        break;
                        
                        //CASO 4: ELIMINAR NOTA M�S ALTA DE UN ALUMNO.     
                        case 4:
                             if (Lista != NULL)  
                             {
                                       printf("\n Introduzca el nombre del alumno: ");
                                       scanf(" %[^\n]",Nombre); 
                                       printf("\n Introduzca los apellidos del alumno: "); 
                                       scanf(" %[^\n]",Apellidos);
                                       EliminarNotas (Lista, Nombre, Apellidos);  
                             }
                             else
                             {
                                 printf("\n No hay alumnos almacenados.");
                             }
                             getchar();
                        break;
                        
                        //CASO 5: ELIMINAR UN ALUMNO JUNTO CON SUS NOTAS.
                        case 5:
                             if (Lista != NULL)  
                             {
                                       printf("\n Introduzca el nombre del alumno: ");
                                       scanf(" %[^\n]",Nombre); 
                                       printf("\n Introduzca los apellidos del alumno: "); 
                                       scanf(" %[^\n]",Apellidos);
                                       EliminarAlumno (&Lista, Nombre, Apellidos);
                                       getchar();  
                             }
                             else
                             {
                                 printf("\n No hay alumnos almacenados.");
                             }
                             getchar();                           
                        break; 
                        
                        //CASO 6: ELIMINAR TODOS LOS ALUMNOS CON SUS RESPECTIVAS NOTAS. 
                        case 6: 
                             if (Lista != NULL)  
                             {
                                       EliminarTodo (&Lista);
                             }
                             else
                             {
                                 printf("\n No hay alumnos almacenados.");
                             }
                             getchar();                            
                        break; 
                        
                        case 7:
                            
                        break; 
                         
                        default:
                                printf ("\n Opcion invalida, vuelve a intentarlo.\n");
                                getchar();
                                getchar();
                        break;
          }
    }while (Opcion!=7);
}
