#ifndef TAD_COLAP_H_
#define TAD_COLAP_H_
 
/***********************************************************************************/
/***********************DECLARAMOS LOS TIPOS DE DATOS*******************************/
/***********************************************************************************/
//DE LA COLA DE PRIORIDAD
typedef int TipoInfoColaP;

typedef struct NodoColaP 
{
        TipoInfoColaP InfoColaP;
        struct NodoColaP *Izdo, *Dcho;
}TipoNodoColaP;

typedef TipoNodoColaP *TipoColaP;

//DE LA COLA
typedef TipoColaP TipoInfoCola;

typedef struct NodoCola
{
	TipoInfoCola InfoCola;
	struct NodoCola *SigCola;
}TipoNodoCola;

typedef TipoNodoCola *TipoCola;

//DE LA LISTA
typedef char TInfoLista[20]; 
typedef struct
{
	 TInfoLista Nombre;
     TInfoLista Apellidos;  
}TipoInfoLista;

typedef struct NodoLista
{
        TipoInfoLista InfoLista;
        struct NodoLista *SigLista;
        TipoColaP Notas;
}TipoNodoLista; 

typedef TipoNodoLista *TipoLista; 

/***********************************************************************************/
/*******************DECLARAMOS LAS FUNCIONES Y/O PROCEDIMIENTOS*********************/
/***********************************************************************************/
//CASO 1 : INSERTAR UN ALUMNO EN LA LISTA.
void InsertarLista (TipoLista *Lista, TInfoLista Nombre, TInfoLista Apellidos);

//CASO 2: INSERTAR NOTAS A UN ALUMNO.
void InsertarNotas(TipoLista Lista, TInfoLista Nombre, TInfoLista Apellidos);
void BuscarAlumno(TipoLista *Lista, TInfoLista Nombre, TInfoLista Apellidos, int *Encontrado);
void PedirDatos(TipoColaP *Monticulo);
void InsertarColaP(TipoColaP *Monticulo, TipoInfoColaP Nota);
TipoCola CrearCola();
int ColaPVacia(TipoColaP Monticulo); 
void InsCola(TipoCola *Cola, TipoColaP Ptr);
TipoColaP SupCola(TipoCola *Cola); 

//CASO 3: IMPRIMIR TODOS LOS ALUMNOS CON LA NOTA MAXIMA DE CADA UNO
void ImprimirTodo(TipoLista Lista);

//CASO 4: ELIMINAR NOTA M�S ALTA DE UN ALUMNO.
void EliminarNotas(TipoLista Lista, TInfoLista Nombre, TInfoLista Apellidos);
void SuprimirColaP(TipoColaP *Monticulo, TipoInfoColaP *ElemTurno);

//CASO 5: ELIMINAR UN ALUMNO JUNTO CON SUS NOTAS.
void EliminarAlumno(TipoLista *Lista, TInfoLista Nombre, TInfoLista Apellidos);
void LimpiarColaP(TipoColaP *Monticulo);
void SuprimirAlumno(TipoLista *Lista, TInfoLista Nombre, TInfoLista Apellidos);

//CASO 6: ELIMINAR TODOS LOS ALUMNOS CON SUS RESPECTIVAS NOTAS.
void EliminarTodo(TipoLista *Lista);

#endif
