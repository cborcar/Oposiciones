/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "TAD_ColaP.h" 
 
/***********************************************************************************/
/**************************FUNCIONES Y PROCEDIMIENTOS*******************************/
/***********************************************************************************/
//CASO 1: INSERTAR UN NUEVO ALUMNO 
//Procedimiento que inserta al alumno en la lista.
void InsertarLista(TipoLista *Lista, TInfoLista Nombre, TInfoLista Apellidos)
{  
     TipoLista Nuevo = NULL;
     TipoLista Ptr = NULL; 
     int Encontrado = 0;  
     Nuevo = ((TipoLista)malloc(sizeof(TipoNodoLista)));
     strcpy (((*Nuevo).InfoLista).Nombre, Nombre);
     strcpy (((*Nuevo).InfoLista).Apellidos, Apellidos);
     (*Nuevo).SigLista = NULL;
     (*Nuevo).Notas = NULL;
     TipoLista Aux = NULL;
     if (*Lista == NULL)
     {
               *Lista = Nuevo;
               printf ("\n Se ha insertado a %s, %s con exito.", ((*(*Lista)).InfoLista).Apellidos, ((*(*Lista)).InfoLista).Nombre);
     } 
     else 
     {
          if (strcmp(Apellidos, ((*(*Lista)).InfoLista).Apellidos) < 0)
          {
                     (*Nuevo).SigLista = *Lista;
                     *Lista = Nuevo;
                     printf ("\n Se ha insertado a %s, %s con exito.", ((*(*Lista)).InfoLista).Apellidos, ((*(*Lista)).InfoLista).Nombre); 
          }
          else
          {
                     Ptr = *Lista;
                     Encontrado = 0;
                     while (((*Ptr).SigLista != NULL) && (Encontrado == 0))
                     {
                         if (strcmp(Apellidos, ((*(*Ptr).SigLista).InfoLista).Apellidos) >= 0)  
                         {
                               if (strcmp(Apellidos, ((*(*Ptr).SigLista).InfoLista).Apellidos) == 0)
                               {
                                     Aux = Ptr;
                                     Ptr = (*Ptr).SigLista;
                                     Encontrado = 1;                                 
                               }
                               else
                               {
                                     Ptr = (*Ptr).SigLista;   
                               }     
                         }
                         else
                         {
                               Encontrado = 1;
                         }
                     }
                     if (strcmp(((*Nuevo).InfoLista).Apellidos, ((*Ptr).InfoLista).Apellidos) != 0)
                     {
                         (*Nuevo).SigLista = (*Ptr).SigLista;
                         (*Ptr).SigLista = Nuevo;
                         printf ("\n Se ha insertado a %s, %s con exito.", ((*Nuevo).InfoLista).Apellidos, ((*Nuevo).InfoLista).Nombre);
                     }
                     else
                     {
                         if (Aux != NULL)
                         {
                                 if (strcmp(((*Ptr).InfoLista).Apellidos, ((*Aux).InfoLista).Apellidos) == 0) 
                                 {
                                            Ptr = Aux;
                                 }
                         }
                         if (strcmp(((*Nuevo).InfoLista).Nombre, ((*Ptr).InfoLista).Nombre) != 0)
                         {
                              if (strcmp(Nombre, ((*Ptr).InfoLista).Nombre) < 0)
                              {
                                    if (Aux == NULL)
                                    {
                                        (*Nuevo).SigLista = Ptr;
                                        *Lista = Nuevo;
                                        printf ("\n Se ha insertado a %s, %s con exito.", ((*Nuevo).InfoLista).Apellidos, ((*Nuevo).InfoLista).Nombre);  
                                    }
                                    else
                                    {
                                        (*Nuevo).SigLista = Ptr;
                                        (*Aux).SigLista = Nuevo;
                                        printf ("\n Se ha insertado a %s, %s con exito.", ((*Nuevo).InfoLista).Apellidos, ((*Nuevo).InfoLista).Nombre); 
                                    }
                              }
                              else
                              {
                                  Encontrado = 0;
                                  while (((*Ptr).SigLista != NULL) && (Encontrado == 0))
                                  {
                                        if (strcmp(Apellidos, ((*(*Ptr).SigLista).InfoLista).Apellidos) == 0)
                                        {
                                            if (strcmp(Nombre, ((*(*Ptr).SigLista).InfoLista).Nombre) >= 0)  
                                            {
                                                 Ptr = (*Ptr).SigLista;
                                            }
                                            else
                                            {
                                                 Encontrado = 1;
                                            }
                                        }
                                        else
                                        {
                                            Encontrado = 1;
                                        }
                                  }
                              
                                  if (strcmp(((*Nuevo).InfoLista).Nombre, ((*Ptr).InfoLista).Nombre) != 0)
                                  {
                                     (*Nuevo).SigLista = (*Ptr).SigLista;
                                     (*Ptr).SigLista = Nuevo;
                                      printf ("\n Se ha insertado a %s, %s con exito.", ((*Nuevo).InfoLista).Apellidos, ((*Nuevo).InfoLista).Nombre);
                                  }
                                  else
                                  {
                                      printf ("\n No se ha insertado ya que %s, %s existe.", Apellidos, Nombre);
                                  }
                              }
                         }
                         else
                         {
                               printf ("\n No se ha insertado ya que %s, %s existe.", Apellidos, Nombre);  
                         }
                     }
          }     
     }
}

//CASO 2: INSERTAR NOTAS A UN ALUMNO.
//Procedimiento para buscar y pedir las notas al alumno al que hay que insertarlas.
void InsertarNotas(TipoLista Lista, TInfoLista Nombre, TInfoLista Apellidos)
{
     int Encontrado = 0;
     BuscarAlumno(&Lista, Nombre, Apellidos, &Encontrado);
     if (Encontrado == 0)
     {
                    printf ("\n Imposible ya que el alumno %s, %s no esta incluido.", Apellidos, Nombre);
                    getchar();   
     }
     else
     {
            PedirDatos(&(*Lista).Notas);
     }   
}

//Procedimiento que busca el alumno deseado, si se encuentra Encontrado = 1,
void BuscarAlumno(TipoLista *Lista, TInfoLista Nombre, TInfoLista Apellidos, int *Encontrado)
{
     while ((*Lista != NULL) && (*Encontrado == 0))
     {
           if ((strcmp(((*(*Lista)).InfoLista).Apellidos, Apellidos) == 0) && (strcmp(((*(*Lista)).InfoLista).Nombre, Nombre) == 0))
           {
                  *Encontrado = 1;
           }
           else
           {
                  *Lista = (*(*Lista)).SigLista;
           }
     }
}

//Procedimiento que pide las notas del alumno encontrado para posteriormente insertarlas.
void PedirDatos(TipoColaP *Monticulo)
{
     TipoInfoColaP Nota = -1;
     char Eleccion;
     printf ("\n Inserte la nota: ");
     scanf("%d",&Nota); 
     if ((Nota < 0) || (Nota > 10))
     {
               printf("\n La nota debe ser un digito entre 0 y 10, pruebe otra vez.\n");
               getchar();
		       PedirDatos(&*Monticulo);               
     }
     else
     {
              InsertarColaP(&*Monticulo, Nota);
              printf ("\n Se ha insertado la nota [%d] con exito.\n", Nota);
              printf ("\n Desea insertar mas notas? (Pulse s si es que si): ");
              scanf(" %c", &Eleccion);
              if (Eleccion == 's')
              {
                  PedirDatos(&*Monticulo);
              }           
     }
}

//Procedimiento para insertar un nodo en la cola de prioridad.
void InsertarColaP(TipoColaP *Monticulo, TipoInfoColaP Nota)
{
	TipoCola Cola1, Cola2, Aux;
	TipoColaP Ptr, Nuevo;
	int Fin, Acabar; 
    int Vacia = 0;
	int Pos, i; 
	Cola1 = CrearCola();
	Cola2 = CrearCola();
	Vacia = ColaPVacia(*Monticulo);
	if (Vacia)
    {
        *Monticulo = (TipoColaP)malloc(sizeof(TipoNodoColaP));
        (*(*Monticulo)).InfoColaP = Nota;
        (*(*Monticulo)).Izdo = NULL;
        (*(*Monticulo)).Dcho = NULL;
    }
    else
    {
		Ptr = *Monticulo;
		Fin = 0;
		InsCola(&Cola1, Ptr);
		while (!Fin)
        {
			Ptr = SupCola(&Cola1);
			InsCola(&Cola2, Ptr);
			if ((*Ptr).Izdo != NULL)
            {
				InsCola(&Cola1, (*Ptr).Izdo);
			}
            else
            {
				(*Ptr).Izdo = (TipoColaP)malloc(sizeof(TipoNodoColaP));
				(*(*Ptr).Izdo).InfoColaP = Nota;
				(*(*Ptr).Izdo).Izdo = NULL;
				(*(*Ptr).Izdo).Dcho = NULL;
				Nuevo = (*Ptr).Izdo;
				Fin = 1;
			}
			if (!Fin)
            {
				if ((*Ptr).Dcho != NULL)
                {
					InsCola(&Cola1, (*Ptr).Dcho);
				}
                else
                {
					(*Ptr).Dcho = (TipoColaP)malloc(sizeof(TipoNodoColaP));
					(*(*Ptr).Dcho).InfoColaP = Nota;
					(*(*Ptr).Dcho).Izdo = NULL;
					(*(*Ptr).Dcho).Dcho = NULL;
					Nuevo = (*Ptr).Dcho;
					Fin = 1;
				}
			}
		}
		//Llegados aqui, ya se ha insertado la nota. Ahora habr�a que reordenar con filtrado ascendente.
		if ((*Nuevo).InfoColaP > (*Ptr).InfoColaP)
        {
			(*Nuevo).InfoColaP = (*Ptr).InfoColaP;
			(*Ptr).InfoColaP = Nota;
			Aux = (*Cola2).SigCola; 
			Pos = 1;
			while ((*Aux).InfoCola != Ptr)
            {
				Pos++; 
				Aux = (*Aux).SigCola;
			}
			 Pos = Pos / 2; 
			 Acabar = 0;
			 while ((Pos >= 1) && (!Acabar))
             {
			 	Aux = (*Cola2).SigCola; 
			 	for (i=1; i<=Pos-1; i++)
                {
			 		Aux = (*Aux).SigCola;
			 	}
			 	if ((*Ptr).InfoColaP > (*(*Aux).InfoCola).InfoColaP)
			 	{
			 		(*Ptr).InfoColaP = (*(*Aux).InfoCola).InfoColaP;
			 		(*(*Aux).InfoCola).InfoColaP = Nota;
			 	}
                else
                {
			 		Acabar = 1;
			 	}
			 	Ptr = (*Aux).InfoCola;
			 	Pos = Pos / 2;
			 }
		}
	}
}

//Funci�n que crea la cola.
TipoCola CrearCola()
{ 
     TipoCola Cola;        
     Cola = NULL;
     return Cola;
}

//Funci�n que comprueba si la cola de prioriodad esta vac�a.
int ColaPVacia(TipoColaP Monticulo)
{
    int Vacia;
    Vacia = (Monticulo == NULL);
    return Vacia;   
}

//Procedimiento para insertar un elemento en la cola.
void InsCola(TipoCola *Cola, TipoColaP Ptr)
{
     TipoCola Nuevo;
     Nuevo = (TipoCola)malloc(sizeof(TipoNodoCola));
     (*Nuevo).InfoCola = Ptr;
     if (*Cola == NULL)
     {
               *Cola = Nuevo;
               (*Nuevo).SigCola = Nuevo;
     }
     else
     {
         (*Nuevo).SigCola = (*(*Cola)).SigCola;
         (*(*Cola)).SigCola = Nuevo;
         *Cola = Nuevo;
     }
}

//Funci�n para borrar un elemento de la cola.
TipoColaP SupCola(TipoCola *Cola)
{
	TipoCola Ptr;
	TipoInfoCola Elemento;
    if ((*(*Cola)).SigCola == (*Cola))
    {
		Elemento = (*(*Cola)).InfoCola;
		*Cola = NULL;
		return (Elemento);
	}
    else
    {
		Ptr = (*(*Cola)).SigCola;
		Elemento = (*Ptr).InfoCola;
		(*(*Cola)).SigCola = (*Ptr).SigCola;
		free(Ptr);
		return (Elemento);
	}
}

//CASO 3: IMPRIMIR TODOS LOS ALUMNOS CON LA NOTA MAXIMA DE CADA UNO
//Procedimiento para listar los alumnos con su nota m�xima.
void ImprimirTodo(TipoLista Lista)
{
     while (Lista != NULL)
     {
           if ((*Lista).Notas == NULL)
           {
               printf("\n %s, %s: No tiene notas asignadas.", ((*Lista).InfoLista).Apellidos, ((*Lista).InfoLista).Nombre);                            
           }
           else
           {
               printf("\n %s, %s: %d", ((*Lista).InfoLista).Apellidos, ((*Lista).InfoLista).Nombre, (*(*Lista).Notas).InfoColaP);
           }
           Lista = (*Lista).SigLista;
     }    
}

//CASO 4: ELIMINAR NOTA M�S ALTA DE UN ALUMNO.
//Procedimiento para buscar al alumno al que hay que suprimir.
void EliminarNotas(TipoLista Lista, TInfoLista Nombre, TInfoLista Apellidos)
{
     TipoInfoColaP ElemTurno;
     TipoLista Aux = Lista;
     int Encontrado = 0;
     char Eleccion = 's';
     BuscarAlumno(&Aux, Nombre, Apellidos, &Encontrado);
     if (Encontrado == 0)
     {
                    printf ("\n Imposible ya que el alumno %s, %s no esta incluido.", Apellidos, Nombre);  
     }
     else
     {
         while (Eleccion == 's')
         {
               SuprimirColaP(&(*Aux).Notas, &ElemTurno);
               if (ElemTurno == -1)
               {
                             printf("\n Imposible ya que %s, %s no tiene notas asignadas.", ((*Aux).InfoLista).Apellidos, ((*Aux).InfoLista).Nombre);                            
                             getchar();
                             Eleccion = 'n';
               }
               else
               {
                   printf ("\n Se ha eliminado la nota [%d] con exito.\n", ElemTurno);
                   printf ("\n Desea eliminar mas notas? (Pulse s si es que si): ");
                   scanf(" %c", &Eleccion);
               }
         }
     }   
}

//Procedimiento para eliminar un nodo de la cola de prioridad.
void SuprimirColaP(TipoColaP *Monticulo, TipoInfoColaP *ElemTurno)
{
     TipoCola Cola1;
	 TipoColaP Ptr, Ult, Penult, Aux;
	 int Fin, Vacia, Acabar;
	 TipoInfoColaP Ultimo;
	 Cola1 = CrearCola();
	 Vacia = ColaPVacia(*Monticulo);
	 if (Vacia)
     {
        *ElemTurno = -1;
	 }
     else
     {
         *ElemTurno = (*(*Monticulo)).InfoColaP;
         if ((*(*Monticulo)).Izdo == NULL)
         {                     
             free(*Monticulo);
             *Monticulo = NULL;
         }
         else
         { 
             Ptr = *Monticulo;
             Fin = 0;
             InsCola(&Cola1, Ptr);
             Ult = Ptr;
             Penult = NULL;
             while (!Fin)
             {
                   Ptr = SupCola(&Cola1);
                   if ((*Ptr).Izdo != NULL)
                   {
                        InsCola(&Cola1, (*Ptr).Izdo);
		                Ult = (*Ptr).Izdo;
		                Penult = Ptr;
                    }
                    else
                    {
                        Fin = 1;
                    }
				    if (!Fin)
                    {
                        if ((*Ptr).Dcho != NULL)
                        {
                             InsCola(&Cola1, (*Ptr).Dcho);
						     Ult = (*Ptr).Dcho;
						     Penult = Ptr;
                        }
                        else
                        {
                            Fin = 1;
					    }
				    }
              }
              Ultimo = (*Ult).InfoColaP;
              if ((*Penult).Izdo == Ult)
              {
				  (*Penult).Izdo = NULL;
              }
              else
              {
                  (*Penult).Dcho = NULL;
              }
              free(Ult);
              //Llegados aqui, ya se ha reemplezado el primer elemento por el �ltimo. Ahora habr�a que reordenar con filtrado descendente.
			  (*(*Monticulo)).InfoColaP = Ultimo;
              Acabar = 0;
              Ptr = *Monticulo;
              while (!Acabar)
              {
                    if ((*Ptr).Izdo != NULL)
                    {
                           Aux = (*Ptr).Izdo;
                           if ((*Ptr).Dcho != NULL)
                           {
                                  if ((*(*Ptr).Dcho).InfoColaP > (*Aux).InfoColaP)
                                  {
                                        Aux = (*Ptr).Dcho;
                                  }
                           }
			 		       if ((*Aux).InfoColaP > (*Ptr).InfoColaP)
                            {
                                  (*Ptr).InfoColaP = (*Aux).InfoColaP;
                                  (*Aux).InfoColaP = Ultimo;
                            }
                            else
                            {
                                Acabar = 1;
                            }
                            Ptr = Aux;
                     }
                     else
                     {
                         Acabar = 1;
                     }
              }
         }
     }
}

//CASO 5: ELIMINAR UN ALUMNO JUNTO CON SUS NOTAS.
//Procedimiento para buscar eliminar al alumno deseado junto con sus notas.
void EliminarAlumno(TipoLista *Lista, TInfoLista Nombre, TInfoLista Apellidos)
{
     TipoLista Aux = *Lista;
     int Encontrado = 0;
     BuscarAlumno(&Aux, Nombre, Apellidos, &Encontrado);
     if (Encontrado == 0)
     {
                    printf ("\n Imposible ya que el alumno %s, %s no esta incluido.", Apellidos, Nombre);  
     }
     else
     {
            LimpiarColaP(&(*Aux).Notas);
		    SuprimirAlumno(&*Lista, Nombre, Apellidos);
		    printf("\n El alumno %s, %s y sus notas se han eliminado.", Apellidos, Nombre);
     }   
}

//Procedimiento que elimina todas las notas de un alumno dado.
void LimpiarColaP(TipoColaP *Monticulo)
{
     TipoInfoColaP Elemento;
     while (*Monticulo != NULL)
     {
           SuprimirColaP(Monticulo, &Elemento);
     }
}

//Procedimiento que borra un alumno de la lista.
void SuprimirAlumno(TipoLista *Lista, TInfoLista Nombre, TInfoLista Apellidos)
{
	TipoLista Suprimir, Anterior;
	int Final, Vacia;
	Suprimir = *Lista;
    Anterior = NULL;
    while ((strcmp(((*Suprimir).InfoLista).Apellidos, Apellidos) != 0) || (strcmp(((*Suprimir).InfoLista).Nombre, Nombre) != 0))
    {
          Anterior = Suprimir;
          if ((*Suprimir).SigLista != NULL)
          {
                Suprimir = (*Suprimir).SigLista;
          }
    }
    if (Suprimir == *Lista)
    {
             *Lista = (*Suprimir).SigLista;
    }
    else
    {
             (*Anterior).SigLista = (*Suprimir).SigLista;
    }
    free (Suprimir);
}

//CASO 6: ELIMINAR TODOS LOS ALUMNOS CON SUS RESPECTIVAS NOTAS.
//Procedimiento eliminar todos los alumnos junto con sus notas.
void EliminarTodo(TipoLista *Lista)
{
     TipoLista Ptr;
     while (*Lista != NULL)
     {
           Ptr = *Lista;
           *Lista = (*(*Lista)).SigLista;
           LimpiarColaP(&(*Ptr).Notas);
           free(Ptr);
     }
     printf ("\n Todos los alumnos y sus notas han sido eliminados con exito.");
}
