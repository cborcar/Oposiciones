#ifndef TAD_Cola_H_
#define TAD_Cola_H_

/***********************************************************************************/
/***********************DECLARAMOS LOS TIPOS DE DATOS*******************************/
/***********************************************************************************/
typedef int TipoInfoCola;

typedef struct NodoCola
{
        TipoInfoCola InfoCola;
        struct NodoCola *SigCola;
}TipoNodoCola;

typedef TipoNodoCola *TipoPunteroCola;

typedef struct
{
        TipoPunteroCola IniCola;
        TipoPunteroCola FinCola;
}TipoCola;

//Nuevo=((TIPO DEL PUNTERO Q APUNTA AL NODO)malloc(sizeof(TIPO DEL NODO QU CREAS);

/***********************************************************************************/
/*******************DECLARAMOS LAS FUNCIONES Y/O PROCEDIMIENTOS*********************/
/***********************************************************************************/
void Menu_cola();
TipoCola CrearCola();
int ColaVacia(TipoCola Cola);
void InsertarCola(TipoCola *Cola, TipoInfoCola Elemento);
void SupCola(TipoCola *Cola);
TipoInfoCola PrimerElem(TipoCola Cola);
TipoInfoCola UltimoElem(TipoCola Cola);
void LimpiarCola(TipoCola *Cola);

#endif
