/***********************************************************************************/
/*********************** PRACTICA 1 - TAD LISTA, COLA Y PILA ***********************/
/***************************** Cayetano Borja Carrillo *****************************/
/***********************************************************************************

/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/
#include <stdio.h>
#include <stdlib.h>

/***********************************************************************************/
/****************************INICIAMOS EL PROGRAMA**********************************/
/***********************************************************************************/
int main ()
{
    int opcion;
    do
    {
          system("cls");
          printf ("\n\n");
          printf ("   |======================================|\n");
          printf ("   |-------------EDA PRACTICA 1-----------|\n");
          printf ("   |-------------MENU PRINCIPAL-----------|\n");
          printf ("   |--------Cayetano Borja Carrillo-------|\n");
          printf ("   |======================================|\n\n");
          printf (" Opcion 1: Listas\n");
          printf (" Opcion 2: Pilas\n");  
          printf (" Opcion 3: Colas\n");
          printf (" Opcion 4: Salir del programa\n\n");
          printf(" Elige una opcion: ");
          scanf("%d", &opcion);
          
          switch(opcion)
          {
                        case 1:
                             Menu_Lista();
                        break;
                        
                        case 2:
                             Menu_Pila();
                        break;
                        
                        case 3:
                             Menu_cola();
                        break;
                        
                        case 4:
       
                        break;  
                                              
                        default:
                                printf ("\n Opcion invalida, vuelve a intentarlo.\n");
                                getchar();
                                getchar();
                        break;
          }
    }while (opcion!=4);
}
