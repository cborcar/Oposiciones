/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "TAD_Lista.h"

/***********************************************************************************/
/****************************INICIAMOS EL PROGRAMA**********************************/
/***********************************************************************************/

void Menu_Lista()
{
    int Vacia = 0;
    int Creada = 0;
    int Opcion = 0;
   	TipoLista Lista;
   	TipoInfoLista Elemento;
    do
    {
          system("cls");
          printf ("\n\n");
          printf ("   |======================================|\n");
          printf ("   |-------------EDA PRACTICA 1-----------|\n");
          printf ("   |-------------OPCION  LISTAS-----------|\n");
          printf ("   |--------Cayetano Borja Carrillo-------|\n");
          printf ("   |======================================|\n\n");
          printf (" Opcion 1: Crear Lista\n");
          printf (" Opcion 2: Comprobar si la lista esta vacia\n");  
          printf (" Opcion 3: Insertar Elemento\n");
          printf (" Opcion 4: Suprimir Elemento\n");
          printf (" Opcion 5: Imprimir Lista\n");  
          printf (" Opcion 6: Buscar Lista\n");
          printf (" Opcion 7: Limpiar Lista\n");
          printf (" Opcion 8: Volver al menu principal\n\n");
          printf(" Elige una opcion: ");
          scanf("%d", &Opcion);
          
          switch(Opcion)
          {
                        //CASO 1 : CREAR LISTA.
                        case 1:
                             if (!Creada)
                             {
                                         Lista = CrearLista();
                                         Creada = 1;
                                         printf("\n La lista ha sido creada con exito.");
                             }
                             else
                             {
                                 printf("\n No se puede crear la lista porque ya esta creada.");
                             }
                             getchar();
                             getchar();
                        break;

                        //CASO 2: COMPROBAR SI LA LISTA EST� VAC�A.                 
                        case 2:
                             if (Creada)
                             {
                                        Vacia = ListaVacia(Lista);
                                        if (Vacia)
                                        {
                                                  printf("\n La lista esta vacia.");
                                                  
                                        }
                                        else
                                        {
                                                  printf("\n La lista contiene elementos.");
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la lista, debes crearla primero.");
                             }  
                             getchar();
                             getchar();                        
                        break;

                        //CASO 3: INSERTAR UN ELEMENTO EN LA LISTA.                  
                        case 3:
                             if (Creada)
                             {
                                        printf("\n Escriba el elemento que desea introducir: ");
                                        scanf(" %d",&Elemento);
                                        InsElemento(&Lista, Elemento);
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la lista, debes crearla primero.");
                             }
                             getchar();
                             getchar();  
                        break;

                        //CASO 4: ELIMINAR UN ELEMENTO DE LA LISTA.                  
                        case 4:
                             if (Creada)
                             {          Vacia = ListaVacia(Lista);
                                        if (Vacia)
                                        {
                                                  printf("\n La lista esta vacia, tienes que insertar algun elemento antes.");
                                        }
                                        else
                                        {
                                                  printf("\n Escriba el elemento que desea eliminar: ");
                                                  scanf(" %d",&Elemento);
                                                  SupElemento(&Lista, Elemento);
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la lista, debes crearla primero.");
                             }
                             getchar();
                             getchar();     
                        break;

                        //CASO 5: IMPRIMIR POR PANTALLA LA LISTA COMPLETA.                
                        case 5:
                             if (Creada)
                             {          Vacia = ListaVacia(Lista);
                                        if (Vacia)
                                        {
                                                  printf("\n La lista esta vacia, tienes que insertar algun elemento antes.");
                                        }
                                        else
                                        {
                                            printf ("\n Los elementos de la lista son:");
                                            ImpLista(Lista); 
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la lista, debes crearla primero.");
                             }
                             getchar();
                             getchar(); 
                        break;

                        //CASO 6: BUSCAR LA POSICI�N DE UN ELEMENTO.                        
                        case 6:
                             if (Creada)
                             {          Vacia = ListaVacia(Lista);
                                        if (Vacia)
                                        {
                                                  printf("\n La lista esta vacia, tienes que insertar algun elemento antes.");
                                        }
                                        else
                                        {
                                            printf("\n Escriba el elemento que desea buscar: ");
                                            scanf(" %d",&Elemento);
                                            BuscarLista(Lista, Elemento);      
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la lista, debes crearla primero.");
                             }
                             getchar();
                             getchar(); 
                        break;
                        
                        //CASO 7: VACIAR LA LISTA DE TODOS LOS ELEMENTOS.              
                        case 7:
                             if (Creada)
                             {          Vacia = ListaVacia(Lista);
                                        if (Vacia)
                                        {
                                                  printf("\n La lista esta vacia, tienes que insertar algun elemento antes.");
                                        }
                                        else
                                        {
                                            LimpiarLista(&Lista);
                                            printf("\n Se han eliminado todos los elementos de la lista."); 
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la lista, debes crearla primero.");
                             }
                             getchar();
                             getchar(); 
                        break;
                        
                         //CASO 8: VUELVE AL MEN� PRINCIPAL.                         
                        case 8:

                        break;
                        
                        //CASO DEFAULT: CUALQUIER OTRA OPCI�N.                          
                        default:
                                printf ("\n Opcion invalida, vuelve a intentarlo.");
                                getchar();
                        break;
                        }

               }while (Opcion!=8);     
     }

/***********************************************************************************/
/**************************FUNCIONES Y PROCEDIMIENTOS*******************************/
/***********************************************************************************/

//FUNCI�N QUE CREA LA LISTA.
TipoLista CrearLista()
{
	TipoLista Ptr;
	Ptr = NULL;
	return Ptr;
}

//FUNCI�N QUE COMPRUEBA SI LA LISTA EST� VAC�A O NO.
int ListaVacia(TipoLista Lista)
{
    int Vacia;
    Vacia = (Lista == NULL);
    return (Vacia);
}

//PROCEDIMIENTO PARA INSERTAR UN ELEMENTO NUEVO EN LA LISTA.
void InsElemento(TipoLista *Lista, TipoInfoLista Elemento)
{
     TipoLista Nuevo, Ptr;
     int Encontrado, Vacia;
     Nuevo = ((TipoLista)malloc(sizeof(TipoNodoLista)));  // Creamos el nodo "Nuevo".
     (*Nuevo).InfoLista = Elemento;
     (*Nuevo).SigLista = NULL;
     Vacia = ListaVacia(*Lista);
     if (Vacia)
     {
               *Lista = Nuevo;
               printf ("\n El elemento se ha insertado con exito.");
     }
     else
     {
         if (Elemento < (*(*Lista)).InfoLista)
         {
                      (*Nuevo).SigLista = *Lista;
                      *Lista = Nuevo;
                      printf ("\n El elemento se ha insertado con exito.");              
         }
         else
         {
             Ptr = *Lista;
             Encontrado = 0;
             while (((*Ptr).SigLista != NULL) && (!Encontrado))
             {
                   if (Elemento >= (*(*Ptr).SigLista).InfoLista)
                   {
                                Ptr = (*Ptr).SigLista;
                   }
                   else
                   {
                       Encontrado = 1;
                   }    
             } 
             if ((*Nuevo).InfoLista != (*Ptr).InfoLista)
             {
                   (*Nuevo).SigLista = (*Ptr).SigLista;
                   (*Ptr).SigLista = Nuevo;
                   printf ("\n El elemento se ha insertado con exito."); 
             }
             else
             {
                   printf ("\n Elemento repetido, no se ha insertado.");
             }    
         }
     }
}

//PROCEDIMIENTO PARA SUPRIMIR UN ELEMENTO DE LA LISTA.
void SupElemento(TipoLista *Lista, TipoInfoLista Elemento)
{
     TipoLista Suprimir, Anterior;
     int Final, Vacia;
     Vacia = ListaVacia(*Lista);
     if (Vacia)
     {
               printf("\n La lista esta vacia, tienes que insertar algun elemento antes.");
     }
     else
     {
         Final = 0;
         Suprimir = *Lista;
         Anterior = NULL;
         while (((*Suprimir).InfoLista != Elemento) && (!Final))
         {
               Anterior = Suprimir;
               if ((*Suprimir).SigLista != NULL)
               {
                                        Suprimir = (*Suprimir).SigLista;
               }
               else
               {
                   Final = 1;
               }
         }
         if (Final)
         {
                   printf("\n Imposible de eliminar ya que el elemento no esta en la lista.");
         }
         else
         {
             if (Anterior == NULL)
             {
                          *Lista = (*Suprimir).SigLista;
             }
             else
             {
                 (*Anterior).SigLista = (*Suprimir).SigLista;
             }
             free (Suprimir);
             printf("\n El elemento se ha eliminado con exito.");
         }        
     }
}

//PROCEDIMIENTO PARA IMPRIMIR POR PANTALLA LA LISTA ENTERA.
void ImpLista(TipoLista Lista)
{
     while (Lista != NULL)
     {
         printf(" [%d] ", (*Lista).InfoLista);
         Lista = (*Lista).SigLista;
     }    
}

//PROCEDIMIENTO QUE BUSCA LA POSICI�N DE UN ELEMENTO.
void BuscarLista (TipoLista Lista, TipoInfoLista Elemento)
{
     int Posicion = 1;
     while ((Lista != NULL) && ((*Lista).InfoLista != Elemento))
     {
         Posicion++;
         Lista = (*Lista).SigLista;
     }
     if (Lista == NULL)
     {
         printf("\n El elemento [%d] no esta en la lista.", Elemento);
     }
     else
     {
         printf("\n El elemento [%d] esta en la posicion [%d].", Elemento, Posicion);            
     }
}

//PROCEDIMIENTO PARA LIMPIAR LA LISTA POR COMPLETO.
void LimpiarLista(TipoLista *Lista)
{
     TipoLista Ptr;
     while (*Lista != NULL)
     {
           Ptr = *Lista;
           *Lista = (*(*Lista)).SigLista;
           free(Ptr);
     }
}
