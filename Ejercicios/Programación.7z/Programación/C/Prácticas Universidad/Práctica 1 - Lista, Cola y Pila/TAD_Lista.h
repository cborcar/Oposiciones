#ifndef TAD_Lista_H_
#define TAD_Lista_H_

/***********************************************************************************/
/***********************DECLARAMOS LOS TIPOS DE DATOS*******************************/
/***********************************************************************************/
typedef int TipoInfoLista;

typedef struct NodoLista
{
        TipoInfoLista InfoLista;
        struct NodoLista *SigLista;
}TipoNodoLista;

typedef TipoNodoLista *TipoLista;

/***********************************************************************************/
/*******************DECLARAMOS LAS FUNCIONES Y/O PROCEDIMIENTOS*********************/
/***********************************************************************************/
void Menu_Lista();
TipoLista CrearLista();
int ListaVacia(TipoLista Lista);
void InsElemento(TipoLista *Lista, TipoInfoLista Elemento);
void SupElemento(TipoLista *Lista, TipoInfoLista Elemento);
void ImpLista(TipoLista Lista);
void BuscarLista (TipoLista Lista, TipoInfoLista Elemento);
void LimpiarLista(TipoLista *Lista);

#endif
