/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "TAD_Pila.h"

/***********************************************************************************/
/****************************INICIAMOS EL PROGRAMA**********************************/
/***********************************************************************************/

void Menu_Pila()
{
    int Vacia = 0;
    int Creada = 0;
    int Opcion = 0;
   	TipoPila Pila;
    TipoInfoPila Elemento;
    do
    {
          system("cls");
          printf ("\n\n");
          printf ("   |======================================|\n");
          printf ("   |-------------EDA PRACTICA 1-----------|\n");
          printf ("   |--------------OPCION PILAS------------|\n");
          printf ("   |--------Cayetano Borja Carrillo-------|\n");
          printf ("   |======================================|\n\n");
          printf (" Opcion 1: Crear Pila\n");
          printf (" Opcion 2: Comprobar si la pila esta vacia\n");  
          printf (" Opcion 3: Insertar Elemento (Push)\n");
          printf (" Opcion 4: Suprimir Elemento (Pop)\n");
          printf (" Opcion 5: Comprobar Cabecera\n");  
          printf (" Opcion 6: Limpiar Pila\n");
          printf (" Opcion 7: Volver al menu principal\n\n");
          printf(" Elige una opcion: ");
          scanf("%d", &Opcion);     
  
         switch(Opcion)
          {
                        //CASO 1 : CREAR PILA.
                        case 1:
                             if (!Creada)
                             {
                                         Pila = CrearPila();
                                         Creada = 1;
                                         printf("\n La pila ha sido creada con exito.");
                             }
                             else
                             {
                                 printf("\n No se puede crear la pila porque ya esta creada.");
                             }
                             getchar();
                             getchar();
                        break;  

                        //CASO 2: COMPROBAR SI LA PILA EST� VAC�A.                 
                         case 2:
                             if (Creada)
                             {
                                        Vacia = PilaVacia (Pila);
                                        if (Vacia)
                                        {
                                                  printf("\n La pila esta vacia.");
                                        }
                                        else
                                        {
                                                  printf("\n La pila contiene elementos.");
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la pila, debes crearla primero.");
                             }                                          
                             getchar();
                             getchar();
                        break; 

                        //CASO 3: INSERTAR UN ELEMENTO EN LA PILA (PUSH).                  
                       case 3:
                            if (Creada)
                            {
                                            printf("\n Escriba el elemento que desea introducir: ");
                                            scanf(" %d",&Elemento);
                                            Push(&Pila,Elemento);
                                            printf("\n El elemento se ha insertado con exito.");
                            }
                            else
                            {
                                 printf("\n Aun no se ha creado la pila, debes crearla primero.");
                            }
                            getchar();
                            getchar();
                        break;   
  
                        //CASO 4: ELIMINAR UN ELEMENTO DE LA PILA (POP).  
                        case 4:
                            if (Creada)
                            {          
                                       Vacia = PilaVacia(Pila);
                                       if (Vacia)
                                       {
                                                  printf("\n La pila esta vacia, tienes que insertar algun elemento antes.");
                                       }
                                       else
                                       {
                                                  Pop(&Pila);
                                       }
                            }
                            else
                            {
                                 printf("\n Aun no se ha creado la pila, debes crearla primero.");
                            }
                            getchar();
                            getchar();
                        break;  
  
                        //CASO 5 : VER QUE ELEMENTO ES LA CABECERA.
                        case 5:
                            if (Creada)
                            {          
                                       Vacia = PilaVacia(Pila);
                                       if (Vacia)
                                       {
                                                  printf("\n La pila esta vacia, tienes que insertar algun elemento antes.");
                                       }
                                       else
                                       {
                                                  Cabecera(Pila);
                                       }
                            }
                            else
                            {
                                 printf("\n Aun no se ha creado la pila, debes crearla primero.");
                            }
                            getchar();
                            getchar();                           
                        break; 
                        
                        //CASO 6: VACIAR LA PILA DE TODOS LOS ELEMENTOS. 
                        case 6:
                            if (Creada)
                            {          
                                       Vacia = PilaVacia(Pila);
                                       if (Vacia)
                                       {
                                                  printf("\n La pila esta vacia, tienes que insertar algun elemento antes.");
                                       }
                                       else
                                       {
                                                  LimpiarPila(&Pila);
                                                  printf("\n Se han eliminado todos los elementos de la pila.");
                                       }
                            }
                            else
                            {
                                 printf("\n Aun no se ha creado la pila, debes crearla primero.");
                            }
                            getchar();
                            getchar(); 
                        break; 
                        
                        //CASO 7: VUELVE AL MEN� PRINCIPAL. 
                        case 7:

                        break;  
                        
                        //CASO DEFAULT: CUALQUIER OTRA OPCI�N.                          
                        default:
                                printf ("\n Opcion invalida, vuelve a intentarlo.");
                                getchar();
                        break;
         }
     }while (Opcion!=7);     
}
                                                                      
/***********************************************************************************/
/**************************FUNCIONES Y PROCEDIMIENTOS*******************************/
/***********************************************************************************/
//FUNCI�N QUE CREA LA PILA.
TipoPila CrearPila()
{
	TipoPila Ptr;
	Ptr = NULL;
	return Ptr;
}

//FUNCI�N QUE COMPRUEBA SI LA LISTA EST� VAC�A O NO.
int PilaVacia(TipoPila Pila)
{
    int Vacia;
    Vacia = (Pila == NULL);
    return Vacia;  
}

//PROCEDIMIENTO PARA INSERTAR UN ELEMENTO NUEVO EN LA PILA (PUSH).
void Push(TipoPila *Pila, TipoInfoPila Elemento)
{
     TipoPila Aux;
     Aux = (TipoPila)malloc(sizeof(TipoNodoPila)); //Creamos el nodo Aux.
     (*Aux).InfoPila = Elemento;
     (*Aux).SigPila = *Pila;
     *Pila = Aux;
}

//PROCEDIMIENTO PARA SUPRIMIR UN ELEMENTO DE LA PILA (POP).
void Pop(TipoPila *Pila)
{
     TipoPila Aux;
     TipoInfoPila Elemento;
     Elemento = (*(*Pila)).InfoPila;
     Aux = *Pila;
     *Pila = (*(*Pila)).SigPila;
     free(Aux);
     printf("\n El elemento [%d] se ha eliminado con exito.", Elemento);
}

//PROCEDIMIENTO PARA INFORMAR CUAL ELEMENTO ES LA CABECERA DE LA PILA.
void Cabecera(TipoPila Pila)
{
     TipoInfoPila Cima;    
     Cima = (*Pila).InfoPila;
     printf("\n La cabecera de la pila es [%d]", Cima);
}

//PROCEDIMIENTO PARA LIMPIAR LA LISTA POR COMPLETO.
void LimpiarPila(TipoPila *Pila)
{
     TipoPila Aux;
     while (*Pila != NULL)
     {
         Aux = *Pila;
         *Pila = (*(*Pila)).SigPila;
         free(Aux);
     }     
}
