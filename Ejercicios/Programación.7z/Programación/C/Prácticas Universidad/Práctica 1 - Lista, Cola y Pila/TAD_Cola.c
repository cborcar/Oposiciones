/***********************************************************************************/
/***************************CARGAMOS LAS LIBRERIAS**********************************/
/***********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "TAD_Cola.h"

/***********************************************************************************/
/****************************INICIAMOS EL PROGRAMA**********************************/
/***********************************************************************************/
void Menu_cola()
{
    int Vacia = 0;
    int Creada = 0;
    int Opcion = 0;
   	TipoCola Cola;
   	TipoInfoCola Elemento;

    do
    {
          system("cls");
          printf ("\n\n");
          printf ("   |======================================|\n");
          printf ("   |-------------EDA PRACTICA 1-----------|\n");
          printf ("   |--------------OPCION COLAS------------|\n");
          printf ("   |--------Cayetano Borja Carrillo-------|\n");
          printf ("   |======================================|\n\n");
          printf (" Opcion 1: Crear Cola\n");
          printf (" Opcion 2: Comprobar si la cola esta vacia\n");  
          printf (" Opcion 3: Insertar Elemento\n");
          printf (" Opcion 4: Suprimir Elemento\n");
          printf (" Opcion 5: Ver Primer Elemento\n");  
          printf (" Opcion 6: Ver Ultimo Elemento\n");
          printf (" Opcion 7: Limpiar Cola\n");
          printf (" Opcion 8: Volver al menu principal\n\n");
          printf(" Elige una opcion: ");
          scanf("%d", &Opcion);
          
          switch(Opcion)
          {
                        //CASO 1 : CREAR COLA.
                        case 1:
                             if (!Creada)
                             {
                                         Cola = CrearCola();
                                         Creada = 1;
                                         printf("\n La cola ha sido creada con exito.");
                             }
                             else
                             {
                                 printf("\n No se puede crear la cola porque ya esta creada.");
                             }
                             getchar();
                             getchar();
                        break;

                        //CASO 2: COMPROBAR SI LA COLA EST� VAC�A.                 
                        case 2:
                             if (Creada)
                             {
                                        Vacia = ColaVacia(Cola);
                                        if (Vacia)
                                        {
                                                  printf("\n La cola esta vacia.");
                                                  
                                        }
                                        else
                                        {
                                                  printf("\n La cola contiene elementos.");
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la cola, debes crearla primero.");
                             }  
                             getchar();
                             getchar();                 
                        break;

                        //CASO 3: INSERTAR UN ELEMENTO EN LA COLA.                  
                        case 3:
                             if (Creada)
                             {
                                        printf("\n Escriba el elemento que desea introducir: ");
                                        scanf(" %d",&Elemento);
                                        InsertarCola(&Cola, Elemento);
                                        printf ("\n El elemento se ha insertado con exito.");
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la cola, debes crearla primero.");
                             }
                             getchar();
                             getchar();
                        break;

                        //CASO 4: ELIMINAR UN ELEMENTO DE LA COLA.                  
                        case 4:
                             if (Creada)
                             {          Vacia = ColaVacia(Cola);
                                        if (Vacia)
                                        {
                                                  printf("\n La cola esta vacia, tienes que insertar algun elemento antes.");
                                        }
                                        else
                                        {
                                                  SupCola(&Cola);
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la cola, debes crearla primero.");
                             }
                             getchar();
                             getchar();    
                        break;

                        //CASO 5: VER EL PRIMER ELEMENTO.                
                        case 5:
                             if (Creada)
                             {          Vacia = ColaVacia(Cola);
                                        if (Vacia)
                                        {
                                                  printf("\n La cola esta vacia, tienes que insertar algun elemento antes.");
                                        }
                                        else
                                        {
                                                  Elemento = PrimerElem(Cola);
                                                  printf("\n El primer elemento de la cola es: %d", Elemento);
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la cola, debes crearla primero.");
                             }
                             getchar();
                             getchar(); 
                        break;

                        //CASO 6: VER EL ULTIMO ELEMENTO.                        
                        case 6:
                             if (Creada)
                             {          Vacia = ColaVacia(Cola);
                                        if (Vacia)
                                        {
                                                  printf("\n La cola esta vacia, tienes que insertar algun elemento antes.");
                                        }
                                        else
                                        {
                                                  Elemento = UltimoElem(Cola);
                                                  printf("\n El ultimo elemento de la cola es: %d", Elemento);
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la cola, debes crearla primero.");
                             }
                             getchar();
                             getchar(); 
                        break;
                        
                        //CASO 7: VACIAR LA COLA DE TODOS LOS ELEMENTOS.              
                        case 7:
                             if (Creada)
                             {          Vacia = ColaVacia(Cola);
                                        if (Vacia)
                                        {
                                                  printf("\n La cola esta vacia, tienes que insertar algun elemento antes.");
                                        }
                                        else
                                        {
                                                  LimpiarCola(&Cola);
                                                  printf("\n Se han eliminado todos los elementos de la cola.");
                                        }
                             }
                             else
                             {
                                 printf("\n Aun no se ha creado la cola, debes crearla primero.");
                             }
                             getchar();
                             getchar(); 
                        break;
                        
                         //CASO 8: VUELVE AL MEN� PRINCIPAL.                         
                        case 8:

                        break;
                        
                        //CASO DEFAULT: CUALQUIER OTRA OPCI�N.                          
                        default:
                                printf ("\n Opcion invalida, vuelve a intentarlo.");
                                getchar();
                        break;
                        }

               }while (Opcion!=8);     
     }

/***********************************************************************************/
/**************************FUNCIONES Y PROCEDIMIENTOS*******************************/
/***********************************************************************************/
//FUNCI�N QUE CREA LA COLA.
TipoCola CrearCola()
{ 
     TipoCola Cola;        
     Cola.IniCola = NULL;
     Cola.FinCola = NULL;
     return Cola;
}

//FUNCI�N QUE COMPRUEBA SI LA COLA EST� VAC�A O NO.
int ColaVacia(TipoCola Cola)
{
    int Vacia;
    Vacia = (Cola.IniCola == NULL);
    return Vacia;
}

//PROCEDIMIENTO PARA INSERTAR UN ELEMENTO NUEVO EN LA COLA.
void InsertarCola(TipoCola *Cola, TipoInfoCola Elemento)
{
     TipoPunteroCola Nuevo, Aux;  
     int Vacia;
     Nuevo =((TipoPunteroCola)malloc(sizeof(TipoNodoCola)));  //Creamos el nodo "Nuevo".
     (*Nuevo).InfoCola = Elemento;
     (*Nuevo).SigCola = NULL;
     Vacia = ColaVacia(*Cola);
     if (Vacia)
     {
         (*Cola).IniCola = Nuevo;
     }
     else
     {
         (*(*Cola).FinCola).SigCola = Nuevo;        
     }
     (*Cola).FinCola = Nuevo;
}

//PROCEDIMIENTO PARA ELIMINAR UN ELEMENTO DE LA COLA.
void SupCola(TipoCola *Cola)
{
     TipoPunteroCola Aux;
     int Vacia;
     TipoInfoCola Elemento;
     Elemento = (*(*Cola).IniCola).InfoCola;
     Aux = (*Cola).IniCola;
     (*Cola).IniCola = (*(*Cola).IniCola).SigCola;
     if ((*Cola).IniCola == NULL)
     {
                         (*Cola).FinCola = NULL;
     }
     free(Aux);
     printf("\n El elemento [%d] se ha eliminado con exito.", Elemento);  
}

//FUNCI�N QUE MUESTRA EL PRIMER ELEMENTO DE LA COLA.
TipoInfoCola PrimerElem(TipoCola Cola)
{
             TipoInfoCola Primero;
             Primero = (*Cola.IniCola).InfoCola;
             return Primero;
}

//FUNCI�N QUE MUESTRA EL �LTIMO ELEMENTO DE LA COLA.
TipoInfoCola UltimoElem(TipoCola Cola)
{
             TipoInfoCola Ultimo;
             Ultimo = (*Cola.FinCola).InfoCola;
             return Ultimo;
}

//PROCEDIMIENTO PARA LIMPIAR LA COLA POR COMPLETO.
void LimpiarCola(TipoCola *Cola)
{
     TipoPunteroCola Aux;
     while ((*Cola).IniCola != NULL)
     {
           Aux = (*Cola).IniCola;
           (*Cola).IniCola = (*(*Cola).IniCola).SigCola;
           free(Aux);
     }
}
