#ifndef TAD_Pila_H_
#define TAD_Pila_H_

/***********************************************************************************/
/***********************DECLARAMOS LOS TIPOS DE DATOS*******************************/
/***********************************************************************************/
typedef int TipoInfoPila;

typedef struct NodoPila
{
        TipoInfoPila InfoPila;
        struct NodoPila *SigPila;
}TipoNodoPila;

typedef TipoNodoPila *TipoPila;

/***********************************************************************************/
/*******************DECLARAMOS LAS FUNCIONES Y/O PROCEDIMIENTOS*********************/
/***********************************************************************************/
void Menu_Pila();
TipoPila CrearPila();
int PilaVacia(TipoPila Pila);
void Push(TipoPila *Pila, TipoInfoPila Elemento);
void Pop(TipoPila *Pila);
void Cabecera(TipoPila Pila);
void LimpiarPila(TipoPila *Pila);

#endif
