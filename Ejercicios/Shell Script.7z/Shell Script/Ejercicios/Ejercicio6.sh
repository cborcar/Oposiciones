#Crea un script que reciba varios parametros. El script debe validar que el primer parametro sea un directorio y que el resto sean archivos, posteriormente, copia esos archivos en ese directorio.

#!/bin/bash
clear
#Primero comprobamos que haya recibido al menos 2 argumentos
if [ $# -le 1 ]; then #-le significa menor o igual
    read -p "Error: Se necesitan al menos 2 argumentos. Ej: Carpeta Archivo1 Archivo2"
	exit
fi

#Segundo copiamos los archivos en el directorio. Antes comprobamos que el primer argumento es una carpeta
if [ -d $1 ]; then #-d devuelve verdadero si la variable es una carpeta
	carpeta=$1
	numarchivos=0
	for i in $*; do #Desde i=0 hasta fin de los argumentos
	#Comprobamos que el resto de argumentos sean realmente archivos
		if [ -f $i ]; then #-f devuelve verdadero si la variable es un archivo
			cp $i $carpeta #El comando "cp" sirve para copiar. Copia el fichero "$i" dentro de carpeta "$carpeta"
			echo "Archivo $i copiado en $carpeta"
			numarchivos=$(( $numarchivos + 1 ))
		else
			if [ $i != $carpeta ]; then #Cuando hay que comparar cadenas no se utiliza -eq, -ne, etc. Se utiliza ==, !=, etc.
				echo "El argumento $i no es un archivo o no existe"
			fi
		fi
        echo ""
	done
	read -p "Se han copiado $numarchivos archivos"
else
	read -p "Error: El primer argumento introducido no es un directorio"
fi