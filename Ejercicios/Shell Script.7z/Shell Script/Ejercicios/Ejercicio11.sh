#Crea un script que salude segun la hora del sistema. Para ello, se ha de tomar el nombre del usuario que lo ejecute y la fecha. Los saludos corresponden a las siguientes horas: de 05:00 hasta 12:59 decir buenos dias, de 13:00 hasta 19;59 decir buenas tardes y de 20:00 hasta 04:59 decir buenas noches. Ejemplo: Buenos dias, Juan.

#!/bin/bash
clear
#Primero tomamos el nombre del usuario.
Usuario=$(whoami)
#Otra forma: Usuario=$(grep "^$LOGNAME" /etc/passwd | cut -d : -f5 | cut -d , -f1)

#Segundo tomamos la hora.
Hora=$((10#$(date +"%H"))) #El 10 se pone para que lo pase a decimal, ya que si sino lo interpreta como octal
#Otra forma: Hora=$(date | cut -d " " -f5 | cut -d : -f1)

#Tercero, mostrar el mensaje dependiendo de la hora.
#Si la hora es >= que 5 y < que 13.
if [[ ( $Hora -ge 5 ) && ( $Hora -lt 13 ) ]]; then #ge y lt es para numeros
    echo "Buenos dias, $Usuario."
else
    #Si la hora es >= que 13 y < que 20.
    if [[ ( $Hora -ge 13 ) && ( $Hora -lt 20 ) ]]; then
        echo "Buenas tardes, $Usuario."
    else
        #Si la hora es >= que 20 o >= que 0 y < que 5.
        if [[ ( $Hora -ge 20 ) ]] || [[ ( $Hora -ge 0 ) && ( $Hora -lt 5 ) ]]; then
            echo "Buenas noches, $Usuario."
        fi  
    fi
fi

read enterkey
