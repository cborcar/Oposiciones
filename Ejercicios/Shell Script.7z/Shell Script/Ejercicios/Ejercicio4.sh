#Crea un script que reciba un nombre de archivo, verifique que existe, lo convierta en ejecutable para el propietario y el grupo y muestre el modo final.

#!/bin/bash
clear
echo ""
if [ $# -eq 0 ]; then 
	read -p "Error: No has introducido ningun parametro"
	exit 
fi

if [ $# -ne 1 ]; then
	read -p "Error: Solo se puede introducir parametro"
	exit 
fi

if [ -f $1 ]; then
	chmod ug+x $1 #Comando "chmod" cambia los permisos. "u" significa usuario y "g" grupo, "+x" le da permiso de ejecucion 
	ls -l $1 #Comando "ls" muestra los archivos y carpetas de ese directorio
else
	echo "Error: El parametro introducido no es un archivo o no existe."
fi
echo ""
read -p "Pulsa cualquier tecla para continuar"