#Crea un script que pida un numero por pantalla y que diga si el numero es par o impar.

#!/bin/bash
clear
echo -n "Introduzca un numero: " #-n es para que no haga un salto de linea
read numero
echo "" #No muestra nada, se usa para hacer un salto de linea
res=$(( $numero % 2)) #La variable "res" será igual a "numero" modulo 2.
if [ $res -eq 0 ]; then #-eq significa igual y solo se usa para comparar numeros. Para cadenas se utiliza ==
    echo "El numero es par."
else
    echo "El numero es impar."
fi
echo ""
read -p "Pulsa cualquier tecla para finalizar"