#Crea un script que muestre los nombres de los usuarios conectados. A continuacion, el script debera pedirnos que ingresemos uno de esos usuarios y, si existe, mostrara su nombre completo y la ruta de su directorio personal.

#!/bin/bash
clear
#Primero mostramos los nombres de los usuarios conectados.
echo "Los usuarios conectados son los siguientes:"
echo ""
who | cut -d " " -f1 | nl #Aqui se ejecutan 3 comandos.
#Comando who: Muestra los usuarios conectados en el sistema.
#Comando cut: Divide cada fila en bloques. -d " " quiere decir que dividira usando un espacio como delimitador. -f1 quiere decir que tomaremos solamente el primer bloque de todos los separados. Otro uso del cut es por ejemplo "cut -c1,5", con esto solo se mostrara el caracter 1 y 5 de cada fila.
#Comando nl: Numera cada fila.

#Ejemplo, si escribimos "who" se mostrara:
	# usuario1 pts/0 2010-05-01 18:00 (:0)"
	# usuario2 pts/1 2010-05-01 18:00 (:0)"
# Escribiendo "cut" y utilizando un espacio como delimitador, nos dividira cada fila en 5 bloques ([usuario1],[pts/0],etc). Como lo unico que nos interesa el el primer bloque escribimos -f1. Despues de eso se mostrara:
	# usuario1
	# usuario2
# Si escribimos nl nos enumerara cada fila quedando finalmente:
	# 1 usuario1
	# 2 usuario2

#Segundo nos pide que ingresemos uno de esos usuarios.
echo ""
echo -n "Escribe un usuario: "
read Usuario

echo ""	
if [ -z $Usuario ]; then #-z devuelve true si la longitud de la cadena es 0
	read -p "Error: No se ha introducido ningun valor"
else
	NombreUsuario=$(grep ^$Usuario /etc/passwd | cut -d : -f5 | cut -d , -f1) #NombreUsuario sera igual a la cadena de texto resultante despues de esos comandos.
	#Comando grep: Muestra lineas donde aparece una palabra. Con "^Usuario /etc/passwd" mostrara la informacion de ese usuario en esa carpeta. El simbolo ^ quiere decir que solo muestre las filas que empiecen por ahi.
	#Comando cut: Nos quedaremos con el quinto bloque si separamos la fila por el delimitador ":"
	#Comando cut: Despues del cut anterior nos quedara "Usuario1,,,", si nos quedamos con el primer bloque utilizando coma como delimitador nos quedaremos finalmente con "Usuario" que es lo que queremos.
	
	HomeUsuario=$(grep ^$Usuario /etc/passwd | cut -d : -f6)
	if [ -z $NombreUsuario ]; then
		read -p "El nombre de usuario escrito no existe"
	else
		echo "El nombre del usuario es: $NombreUsuario"
		echo "Su carpeta personal es: $HomeUsuario"
		echo ""
		read -p "Pulsa cualquier tecla para continuar ..."
	fi
fi