#Crea un script que muestre por pantalla 3 opciones. La opcion 1 muestra los nombres, el numero de grupo y la lista de usuarios ordenados por nombre. La opcion 2 hace lo mismo pero ordenado por numero de grupo. La opcion 3 muestra el nombre de la maquina, la hora y fecha.

#!/bin/bash
while true; do
    clear
    echo "Opcion 1: Listar nombres, num de grupo y lista de usuarios ordenados por nombre"
    echo "Opcion 2: Listar nombres, num de grupo y lista de usuarios ordenados por grupo"
    echo "Opcion 3: Mostrar el nombre de la maquina, la hora y la fecha"
    echo "Opcion 4: Salir"
    echo ""
    echo -n "Elige una opcion: "
    read opcion
    echo ""
    case $opcion in
        1)
            echo "Nombre : Numero de grupo : Lista de usuarios"
            echo ""
            cat /etc/group | cut -d : -f1,3,4 | sort | more -21
        ;;
        2)
            echo "Nombre : Numero de grupo : Lista de usuarios"
            echo ""
            cat /etc/group | cut -d : -f1,3,4 | sort -t: -n -k2
            #Comando "sort -t: -n -k2". Con -t decimos que usaremos ":" de delimitador. Con -n que lo que se van a ordenar son numeros. Con -k2 que ordene el bloque 2 que es el grupo. #NOTA: Si no se hubiera puesto -t y hay los siguientes valores: 1, 2, 11, 16, 22 hubiera ordenado de la siguiente manera: 1,11,16,2,22, por eso hay que decir que son numeros.   
        ;;
        3)
            echo "Nombre de la maquina:" `hostname`
            #El comando "hostname" muestra el nombre de la maquina, se tiene que poner entre "`" porque sino, en vez de mostrar el nombre, muestra la palabra hostname literalmente.
            echo "Fecha:" `date`
        ;;
        4)
            exit
        ;;
        *)
            echo "Opcion incorrecta. Vuelve a intentarlo"
        ;;
    esac
    read enterkey
done
