#Crea un script que muestre la siguiente informacion de configuracion del sistema:
#1. Usuario que ha iniciado la sesion actualmente y su nombre.
#2. Tu shell actual.
#3. Tu directorio home.
#4. El tipo de tu sistema operativo.
#5. La configuracion actual del path.
#6. Tu directorio actual de trabajo.
#7. El numero total de usuarios que han iniciado sesion.
#8. La informacion sobre el SO: version del nucleo y version SO.
#9. Todos los shells disponibles.
#10. La configuracion del raton.
#11. Informacion sobre la CPU: Tipo, velocidad, etc.
#12. Informacion sobre la memoria del sistema.
#13. Informacion sobre el sistema de archivos (si esta montado).
#Escribir un menu que nos permita la consulta e introducir cada punto en una funcion.

#!/bin/bash

############### IMPLEMENTAMOS LAS FUNCIONES ##############
function opcion1 {
	echo "Nombre del usuario: $USER"
	echo "Nombre de login: $LOGNAME"
	#Otra forma:
	#echo "Nombre del usuario: `grep "$USER" /etc/passwd | cut -d : -f1`"
	#echo "Nombre de login: `grep "$LOGNAME" /etc/passwd | cut -d : -f1`"
}

function opcion2 {
	echo "Shell actual: $SHELL"
	#Otra forma:
	#echo "Shell actual: `grep "$LOGNAME" /etc/passwd | cut -d : -f7`"
}

function opcion3 {
	echo "Directorio home: $HOME"
	#Otra forma:
	#echo "Directorio home: `grep "$LOGNAME" /etc/passwd | cut -d : -f6`"
}

function opcion4 {
	echo "El tipo del sistema operativo es: $OSTYPE"
	#Otra forma:
	#echo "El tipo del sistema operativo es: `uname -o`"
	#Comando uname muestra informacion del sistema. -o muestra informacion del sistema operativo.
}

function opcion5 {
	echo "La configuracion actual del path es: $PATH"
}

function opcion6 {
	echo "El directorio actual es: `pwd`"
}

function opcion7 {
	usuarios=`who | wc -l`
	#Comando  who: 
	#Comando wc: Cuenta dependiendo de un patron. -l cuenta las lineas.
	echo "Numero de usuarios conectados: $usuarios"
	#Otra forma:
	#echo "Numero de usuarios conectados: `who | wc -l`"
}

function opcion8 {
	echo "Version del nucleo: `uname -r`"
	echo "Version del sistema operativo `uname -v`"
	#Posiblemente la version del sistema operativo tambien funcione con: cat /etc/issue
	#Escribiendo "cat /proc/version/" tambien aparece la version.
}

function opcion9 {
	echo "Los shell disponibles son los siguientes: "
	cat /etc/shells
}

function opcion10 {
	echo "Opcion no terminada"
}

function opcion11 {
	echo "La informacion sobre la CPU es la siguiente: "
	cat /proc/cpuinfo
}

function opcion12 {
	echo "La informacion sobre la memoria del sistema es la siguiente: "
	#cat /proc/meminfo   ##Supongo que este valdra pero no me gusta mucho.
	free #Este me gusta mas, muestra estadisticas del uso de la memoria
}

function opcion13 {
	echo "Opcion no terminada"
}

function opcion14 {
	echo "Opcion no terminada"
}

################## EMPEZAMOS EL PROGRAMA #################
opcion=0
while [ $opcion -ne 15 ]; do
	clear
	echo "1) Usuario que ha iniciado la sesion actualmente y su nombre."
	echo "2) Tu shell actual."
	echo "3) Tu directorio home."
	echo "4) El tipo de tu sistema operativo."
	echo "5) La configuracion actual del path."
	echo "6) Tu directorio actual de trabajo."
	echo "7) El numero total de usuarios que han iniciado sesion."
	echo "8) La informacion sobre el SO: version del nucleo y version del SO."
	echo "9) Todos los shells disponibles."
	echo "10) La configuracion del raton."
	echo "11) Informacion sobre la CPU: Tipo, velocidad, etc."
	echo "12) Informacion sobre la memoria del sistema."
	echo "13) Informacion sobre el disco duro: Tamano, cache, modelo, etc."
	echo "14) Informacion sobre el sistema de archivos (si esta montado)."
	echo "15) Salir."
	echo ""
	echo -ne "Escoge una opcion: "
	read opcion
	echo ""
	case $opcion in
		1)
			opcion1
		;;
		2)
			opcion2
		;;
		3)
			opcion3
		;;
		4)
			opcion4
		;;
		5)
			opcion5
		;;
		6)
			opcion6
		;;
		7)
			opcion7
		;;
		8)
			opcion8
		;;
		9)
			opcion9
		;;
		10)
			opcion10
		;;
		11)
			opcion11
		;;
		12)
			opcion12
		;;
		13)
			opcion13
		;;
		14)
			opcion14
		;;
		15)
			exit
		;;
		*)
			echo "Opcion invalida, vuelve a intentarlo"
		;;
	esac
	read enterkey
done