#Crea un script llamado informe.sh que muestre la informacion sobre el uso del sistema. El script tendra la siguiente sintaxis: informe.sh opcion [usuario]
#Las opciones pueden ser -u y -a. Si la opcion es -u, debera recibir como segundo argumento un nombre de usuario y mostrara la informacion sobre ese usuario. Si la opcion es -a mostrara la informacion total del sistema.
#La informacion que mostrar es la siguiente:
#-	Nombre del usuario (solo si la opcion es -u).
#-	Numero de procesos que ha lanzado.
#-	Nombre del primer proceso que lanzo.
#-	Listado de todos los procesos que ha lanzado.
#-	Numero de directorios que tiene.
#-	Numero de ficheros regulares que tiene.
#-	Uso del espacio en disco que ocupa.
#-	Tanto por ciento de espacio en disco usado.

#!/bin/bash

############### IMPLEMENTAMOS LAS FUNCIONES ##############
#Funcion Error: Muestra un error.
function Error
{
	echo ""
	echo "Utiliza '$0 -u usuario' para presentar un informe de ese usuario."
	echo "Utiliza '$0 -a' para presentar un informe total del sistema."
	echo "Si se introducen mas parametros de los necesarios, seran omitidos."
	echo ""
	exit

}

#Funcion NombreUsuario: Muestra el nombre de usuario.
function NombreUsuario
{
	clear
	echo "El nombre del usuario es: $NomUsuario"
	read enterkey
}

#Funcion NumProcesos: Muestra el numero de procesos en ejecucion.
function NumProcesos
{
	clear
	#Si se introdujo "-u" muestra el num de procesos del usuario, sino los totales.
	if [[ $Eleccion == "-u" ]]; then
		NumProcesos=$( ps -U $NomUsuario | wc -l )
		#Comando "ps": Muestra los procesos en ejecucion. -U muestra solo los de ese usuario.
		#Comando "wc": Cuenta dependiendo de un patron. -l cuenta las lineas.
		NumProcesos=$(( $NumProcesos - 1 )) #Hay que quitar 1 ya que la linea 1 es la leyenda no un proceso.
		echo "Numero de procesos que ha lanzado $NomUsuario: $NumProcesos"
	else
		NumProcesos=$( ps -e | wc -l )
		NumProcesos=$(( $NumProcesos - 1))
		#Comando "ps": -e muestra todos los procesos del sistema.
		echo "Numero de procesos totales cargados en el sistema: `ps -e | wc -l`"
	fi
	read enterkey
}

#Funcion NomPrimerProceso: Muestra el nombre del primer proceso que se ha ejecutado.
function NomPrimerProceso
{
	clear
	if [[ $Eleccion == "-u" ]]; then
		#Hay que saber antes cuantos procesos ha ejecutado ese usuario por si son 0 omitir esta operacion.
		NumProcesos=$( ps -U $NomUsuario | wc -l )
		NumProcesos=$(( $NumProcesos - 1 ))
		if [[ NumProcesos -ne 0 ]]; then	
			echo "Primer proceso que ha lanzado $NomUsuario: `ps -F -U $NomUsuario | head -2 | tail -1 | awk '{print $11}'`"
			#Comando "ps": -F Muestra informacion completa.
			#Comando "head": Muestra las 10 primeras lineas. -2 solo muestra las 2 primeras lineas.
			#Comando "tail": Muestra las 10 ultimas lineas. -1 solo muestra la ultima linea.
			#Comando "awk":  El comando "cut" es bueno cuando los bloques de todas las lineas son del mismo tamano, pero cuando son diferentes es mejor usar el comando "awk". "awk '{print $x}'" muestra el bloque x.
			read enterkey
		fi
	else
		echo "Primer proceso lanzado por el sistema: `ps -e -F | head -2 | tail -1 | awk '{print $11}'`"
		read enterkey
	fi
}

#Funcion ListadoTodosProcesos: Muestra un listado de todos los procesos en ejecucion.
function ListadoTodosProcesos
{
	clear
	if [[ $Eleccion == "-u" ]]; then
		NumProcesos=$( ps -U $NomUsuario | wc -l )
		if [[ NumProcesos -ne 1 ]]; then
			echo "El listado de todos los procesos que ha lanzado $NomUsuario es:"
			echo ""
			ps -F -U $NomUsuario | tail -$NumProcesos | awk '{print $11}' | more -d -21
			#Si no escribimos "tail" se muestra la leyenda como primer proceso y no lo es, de esta forma se oculta.
			read enterkey
		fi
	else
		NumProcesos=$( ps -e | wc -l)
		echo "El listado de todos los procesos que hay cargados en el sistema es:"
		echo ""
		ps -e -F | tail -$NumProcesos | awk '{print $11}' | more -d -21
		read enterkey
	fi
}

#Funcion NumDirectorios: Muestra el numero de directorios y subdirectorios.
function NumDirectorios
{
	clear
	if [[ $Eleccion == "-u" ]]; then
		carpetausuario=`cat /etc/passwd | grep ^$NomUsuario | cut -d: -f6` 
    		echo "El numero de directorios y subdirectorios de $NomUsuario es: `find $carpetausuario -type d | wc -l`"
			#Comando  "find": Busca archivos y carpetas. -type d busca directorios
	else
		find /. -type d | wc -l >> temporal.$$$ #Almaceno el resultado en un fichero. Lo hago asi para que no se muestre si existe algun permiso denegado.
		clear
		echo "El numero de directorios y subdirectorios del sistema es: `more temporal.$$$`" #Muestro el valor del fichero
		rm temporal.$$$	#Borro el fichero.
	fi
	read enterkey
}

#Funcion NumFicheros: Muestra el numero de ficheros.
function NumFicheros
{
	clear
	if [[ $Eleccion == "-u" ]]; then
		carpetausuario=`cat /etc/passwd | grep ^$NomUsuario | cut -d: -f6` 
    		echo "El numero de ficheros de $NomUsuario es: `find $carpetausuario -type f | wc -l`"
	else
		find /. -type f | wc -l >> temporal.$$$ #Almaceno el resultado en un fichero. Lo hago asi para que no se muestre si existe algun permiso denegado.
	 	clear
		echo "El numero de ficheros del sistema es: `more temporal.$$$`" #Muestro el valor del fichero
		rm temporal.$$$	#Borro el fichero.
	fi
	read enterkey
}

#Funcion EspacioEnDisco: Muestra el espacio utilizado en disco.
function EspacioEnDisco
{
	clear
	if [[ $Eleccion == "-u" ]]; then
		carpetausuario=`cat /etc/passwd | grep ^$NomUsuario | cut -d: -f6` 
    		echo "El espacio en disco ocupado por $NomUsuario es: `du -sh $carpetausuario | awk '{print$1}'`"
		#Comando "du": Calcula el espacio usado desde determinada carpeta. -s suma el total. -h te lo pone en formato KB, MB, ...
	else
		#Para calcular el espacio por disco, se podria hacer de la misma forma que el anterior poniendo que la carpeta es la raiz "/." pero solo sera valido si estamos conectados como administrador ya que, si no, no se podra calcular el espacio en carpetas protegidas con permisos. Para solucionar esto se utilizara la siguiente sintaxis:
		echo "El espacio de disco total ocupado es: `df -h | head -2 | tail -1 | awk '{print$3}'`"
		#Comando df: Muestra informaci�n sobre el espacio ocupado por el disco duro. -h te lo pone en formato humano (KB, MB, ...)
	fi
	read enterkey
}

#Funcion TantoPorCiento: Muestra el tanto por ciento ocupado en disco.
function TantoPorCiento
{
	clear
	if [[ $Eleccion == "-u" ]]; then
		#Primero calculo el espacio ocupado por el usuario en KB.
		carpetausuario=`cat /etc/passwd | grep ^$NomUsuario | cut -d: -f6` 
    		espacioocupado=$( du -s $carpetausuario | awk '{print$1}' )
		#Ahora calculo el espacio total de disco en KB.
		tamanodisco=$( df | head -2 | tail -1 | awk '{print$2}' )
		#Ahora hacemos una regla de 3 para calcular el tanto por ciento.
		#porcentaje=$(( ( $espacioocupado * 100 ) / $tamanodisco )) #Esta expresion seria lo normal, pero no muestra decimales. Hay que usar bc.
		porcentaje=$( echo "scale=2;$espacioocupado*100/$tamanodisco" | bc ) #scale=2 utiliza 2 decimales.
		echo "El porcentaje de espacio de disco ocupado por $NomUsuario es: $porcentaje %"

	else
		echo "El porcentaje de espacio de disco total ocupado es: `df | head -2 | tail -1 | awk '{print$5}'`"
	fi
	read enterkey
}

################## EMPEZAMOS EL PROGRAMA #################
clear
#Comprobamos que se hayan introducido al menos un parametro.
if [[ $# -eq 0 ]]; then
	echo "Error: No has introducido ningun parametro"
	Error
fi

#Comprobamos que el primer parametro sea "-u" o "-a".
if [[ ( $1 == "-u" ) || ( $1 == "-a" ) ]]; then
	Eleccion=$1
	#Comprobamos que si el primer parametro es "-u", se haya introducido un segundo parametro.
	if [[ ( $1 == "-u" ) && ( $2 == "" ) ]]; then
		echo "Error: No has introducido ningun usuario"
		Error
	else
		if [[ $1 == "-u" ]]; then
			NomUsuario=$2
			#Comprobamos que el segundo parametro sea un usuario real.
			if id $NomUsuario > /dev/null 2>&1; then
			#Otra forma de hacerlo:
			#NomUsuario=$(grep -w ^$2 /etc/passwd | cut -d : -f1) #-w significa que contenga exactamente.
			#if [[ $NomUsuario != "" ]]; then
				NombreUsuario
			else
				echo "Error: El usuario introducido no existe o no esta conectado"
				Error
			fi
		fi
		NumProcesos
		NomPrimerProceso
		ListadoTodosProcesos
		NumDirectorios
		NumFicheros
		EspacioEnDisco
		TantoPorCiento
	fi
else
	echo "Error: El parametro introducido no es -u ni -a"
	Error
fi
exit