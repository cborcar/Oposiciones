#Escribe un script que muestre un menu como el siguiente:
#a)	Visualizar el contenido del directorio actual en formato largo
#b)	Visualizar el contenido del directorio actual
#c)	Mostrar el contenido de un fichero
#d)	Salir


#!/bin/bash
while true ; do #Mientras sea verdadero haz
    clear
    echo "a) Visualizar el contenido del directorio actual en formato largo"
    echo "b) Visualizar el contenido del directorio actual"
    echo "c) Mostrar el contenido de un fichero"
    echo "d) Salir"
    echo -n "Escoge una opcion: "
    read opcion
    echo "" 
    case $opcion in #Segun $opcion haz
        a) # Se ha escrito a
            ls -l
        ;; # Como el break de C
        b)  
            ls
        ;;
        c)
            echo -n "Introduce el nombre del archivo: "
            read fichero
			echo ""
            if [ -f $fichero ]; then #Si es un fichero, entonces
                cat $fichero #"cat" muestra contenido de carpetas o archivos
            else
                echo "El texto introducido no es un fichero"           
            fi
        ;;
        d)
            exit
		;;
		*) # Se escribe cualquier otra opcion
			echo "Opcion incorrecta. Vuelve a intentarlo"
		;;
	esac # Fin del case
	read enterkey #Espera a que se pulse una tecla
done # Fin del while