#Crear un script que reciba un nombre de directorio como parametro, validar su existencia y condicion de directorio y mostrar los nombres de todos los directorios y subdirectorios bajo el en formato de pagina largo 23.

#!/bin/bash
clear
if [ $# -eq 0 ]; then
	read -p "Error: No has introducido ningun parametro"
	exit
fi

if [ $# -ne 1 ]; then
	read -p "Error: Solo se puede introducir un parametro"
	exit
fi

if [ -d $1 ]; then
	ls -lR $1 | grep "^d" | pr -l 24 | more -24 #Aqui se ejecutan 4 comandos, el simbolo | se llama tuberia y se utiliza para encadenar comandos (la salida de un comando sera la entrada del otro).
	
	# Comando ls: Muestra todos los archivos y carpetas de un directorio. -l lo muestra en formato largo. R muestra todos sus subdirectorios y los subdirectorios de sus subdirectorios
	
	# Comando grep: Muestra lineas donde aparece una palabra. "^d" muestra solo las lineas que empiecen por "d", es decir, los directorios. Si se escribiera "d" muestra las lineas que contengan una "d" y si se escribe -v "d" muestra los que no contengan "d". Considerando esto, tambien se podia haber escrito "grep -v "^-" ya que ocultamos todo lo que no son directorios.
	
	# Comando pr -l 24: Muestra en cada pantalla 24 lineas.
	
	# Comando more -24: El comando "pr" muestra todas las lineas separadas en pantallas de golpe, el comando more -24 muestra las primeras 24 lineas y despues pide que le pulses un boton para mostrar mas.
else
	read -p "Error: El parametro introducido no es un directorio"
fi