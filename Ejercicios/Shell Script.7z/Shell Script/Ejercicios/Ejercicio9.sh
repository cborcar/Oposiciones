#Crea un script que liste los nombres de login, el directorio propio del usuario y el interprete invocado por defecto de todos los usuarios, ordenados alfabeticamente por nombre de login.

#!/bin/bash
clear
cat /etc/passwd | cut -d : -f1,6,7 | sort | more
#Comando cat: Muestra contenido de carpetas o archivo. Escribiendo "cat /etc/passwd" nos muestra muchas lineas como las siguientes:
	#colord:x:102:105:colord management daemon,,,:/var/lib/colord:/bin/false
	#messagebus:x:103:107::/var/run/dbus:/bin/false
	#lightdm:x:104:108:Light Display Manager:/var/lib/lightdm:/bin/false
#Con "cut" tomaremos el bloque 1, el 6 y el 7.
#Con "sort" Ordenamos las filas.
#Con "more" nos muestra una pantalla y luego nos pide que pulsemos un boton para mostrar mas. 
echo ""
