#Crea un script que reciba un nombre de archivo como parametro e indicar si el archivo es legible, modificable y ejecutable por el usuario

#!/bin/bash
clear
#Comprobamos si se ha introducido algun parametro
if [ $# -eq 0 ]; then #$# es una variable cuyo valor sera el numero de parametros introducidos
	read -p "Error: No has introducido ningun parametro"
	exit #Sale directamente del programa.
fi

#Comprobamos que solo se haya insertado 1 parametro
if [ $# -ne 1 ]; then #-ne significa distinto y solo se usa para comparar numeros, para cadenas se utiliza !=
	read -p "Error: Solo se puede introducir un parametro"
	exit
fi

#Ahora hay que comprobar si el parametro insertado es un fichero o archivo
if [ -f $1 ]; then #$1 contiene el primer parametro. -f devuelve verdadero si la variable $1 es un archivo existente y falso si no lo es.
	if [ -r $1 ]; then #-r devuelve verdadero si el archivo tiene permiso de lectura.
		echo "El fichero es legible"
	fi
	if [ -w $1 ]; then #-w devuelve verdadero si el archivo tiene permiso de escritura.
		echo "El fichero es modificable"
	fi
	if [ -x $1 ]; then #-x devuelve verdadero si el archivo tiene permiso de ejecucion.
		echo "El fichero es ejecutable"
	fi
    echo ""
    read -p "Pulsa cualquier tecla para continuar"
else
	read -p "Error: El parametro introducido no es un fichero o no existe"
fi