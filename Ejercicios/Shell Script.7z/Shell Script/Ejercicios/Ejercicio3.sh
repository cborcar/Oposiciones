#Crea un script que reciba nombres de archivos como parametros. Despues que haga un recorrido de cada parametro y, si el parametro es un archivo, que muestre su contenido.

#!/bin/bash
clear
if [ $# -eq 0 ]; then 
	read -p "Error: No has introducido ningun parametro"
	exit 
fi

#Hacer desde el primer parametro hasta el ultimo
for i in $*; do #$* es una variable que contiene una cadena de texto con todos los parametros pasados
	clear
	if [ -f $i ]; then 
		more $i #"more $i" muestra el contenido de ese archivo
	else
		echo "$i no es un archivo o no existe"
	fi
	echo ""
	read -p "Pulsa cualquier tecla para continuar"
done
